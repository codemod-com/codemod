/*! @license
*/
"use strict";var A=Object.create;var D=Object.defineProperty;var I=Object.getOwnPropertyDescriptor;var O=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,R=Object.prototype.hasOwnProperty;var T=(t,e)=>{for(var n in e)D(t,n,{get:e[n],enumerable:!0})},h=(t,e,n,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of O(e))!R.call(t,s)&&s!==n&&D(t,s,{get:()=>e[s],enumerable:!(r=I(e,s))||r.enumerable});return t};var b=(t,e,n)=>(n=t!=null?A(_(t)):{},h(e||!t||!t.__esModule?D(n,"default",{value:t,enumerable:!0}):n,t)),w=t=>h(D({},"__esModule",{value:!0}),t);var q={};T(q,{repomod:()=>z});module.exports=w(q);var g=require("node:path"),a=b(require("ts-morph"),1),C=t=>t.replace(/^\n+/,"");var L=new Map([["ORIGINAL_PAGE",""],["ROUTE_PAGE",""]]),G=(t,e)=>{let r=new a.default.Project({useInMemoryFileSystem:!0,skipFileDependencyResolution:!0,compilerOptions:{allowJs:!0}}).createSourceFile(t??"",e);return r.getDescendantsOfKind(a.SyntaxKind.StringLiteral).some(i=>i.getLiteralText()==="use client")||r.insertStatements(0,"'use client';"),{kind:"upsertData",path:t,data:r.getFullText()}},K=["dynamic","dynamicParams","revalidate","fetchCache","runtime","preferredRegion","maxDuration"],M=t=>{let e=null,n=a.Node.isParameterDeclaration(t)?t:t.getFirstAncestorByKind(a.SyntaxKind.Parameter),r=t.getFirstAncestorByKind(a.SyntaxKind.ImportDeclaration);return n!==void 0?e=n:r!==void 0?e=r:a.Node.isFunctionDeclaration(t)?e=t:a.Node.isVariableDeclaration(t)?e=t.getParent()?.getParent()??null:a.Node.isBindingElement(t)&&(e=t.getFirstAncestorByKind(a.SyntaxKind.VariableStatement)??null),e},N=3,x=(t,e=0)=>{if(e>N)return{};let n={};return t.forEach(r=>{let s=r.getParent();if(a.Node.isParameterDeclaration(s)||(a.Node.isPropertyAccessExpression(s)||a.Node.isElementAccessExpression(s))&&r.getChildIndex()!==0||a.Node.isPropertyAssignment(s)&&s.getNameNode()===r)return;let[i]=r.getSymbol()?.getDeclarations()??[],d=r.getFirstAncestorByKind(a.SyntaxKind.SourceFile);if(i===void 0||i.getFirstAncestorByKind(a.SyntaxKind.SourceFile)!==d)return;let l=M(i);if(l===null||(n[r.getText()]=l.getText(),a.Node.isImportDeclaration(l)||a.Node.isParameterDeclaration(l)))return;let f=l.getDescendantsOfKind(a.SyntaxKind.Identifier).filter(c=>{if(c.getText()===r.getText()||l&&a.Node.isFunctionDeclaration(l)&&c.getSymbol()?.getDeclarations()[0]?.getFirstAncestorByKind(a.SyntaxKind.FunctionDeclaration)===l)return!1;let u=c.getParent();return!a.Node.isBindingElement(u)&&!a.Node.isPropertyAssignment(u)&&!(a.Node.isPropertyAccessExpression(u)&&c.getChildIndex()!==0)}),m=x(f,e+1);Object.assign(n,m)}),n},k=t=>{let e="";return t.getVariableStatements().forEach(n=>{n.getDeclarations().forEach(r=>{let s=r.getName()??"";r.hasExportKeyword()&&K.includes(s)&&(e+=`${n.getText()} 
`)})}),e},v=t=>{let e="",n=t.getDescendantsOfKind(a.SyntaxKind.ArrowFunction).find(i=>{let d=i.getParent();return a.Node.isVariableDeclaration(d)&&d.getName()==="getData"});if(n===void 0)return e;let r=n.getBody().getDescendantsOfKind(a.SyntaxKind.Identifier),s=x(r);return e+=Object.values(s).reverse().join(`
`),e+=`${n.getFirstAncestorByKind(a.SyntaxKind.VariableStatement)?.getText()??""} 
`,e},B=t=>((t.getLastChildByKind(a.SyntaxKind.ImportDeclaration)??null)?.getChildIndex()??0)+1,j=(t,e,n,r)=>{let{tsmorph:s}=t.getDependencies();return{kind:"upsertData",path:e,data:((d,l)=>{let f=new s.Project({useInMemoryFileSystem:!0,skipFileDependencyResolution:!0,compilerOptions:{allowJs:!0}}),m=typeof n.oldPath=="string"?n.oldPath:null,c=f.createSourceFile(e??"",d),u=f.createSourceFile(m??"",l),P=k(u);c.addStatements(P);let y=v(u),S=B(c);return c.insertStatements(S,y),c.getFunctions().forEach(o=>{if(o.isDefaultExport()){o.remove();return}let p=o.getName()??"";["getStaticProps","getServerSideProps","getStaticPaths"].includes(p)&&o.setIsExported(!1)}),c.getVariableStatements().forEach(o=>{o.getDeclarations().forEach(p=>{let E=p.getName()??"";["getStaticProps","getServerSideProps","getStaticPaths"].includes(E)&&p.hasExportKeyword()&&o.setIsExported(!1)})}),c.getDescendantsOfKind(a.SyntaxKind.JsxOpeningElement).filter(o=>o.getTagNameNode().getText()==="Head").map(o=>o.getFirstAncestorByKind(a.SyntaxKind.JsxElement)).forEach(o=>{let p=o?.getParentIfKind(a.SyntaxKind.ParenthesizedExpression)??null;if(p!==null){p.replaceWithText("null");return}o?.replaceWithText("")}),r==="ROUTE_PAGE"&&c.getImportDeclarations().forEach(o=>{let p=o.getModuleSpecifierValue();p.startsWith("./")?o.setModuleSpecifier(`.${p}`):p.startsWith("../")&&o.setModuleSpecifier(`../${p}`)}),c.getFullText()})(String(n.oldData??""),String(n.legacyPageData??""))}},F=["getStaticProps","getServerSideProps"],W=t=>t.getFunctions().some(e=>F.includes(e.getName()??""))||t.getVariableStatements().some(e=>e.getDeclarations().some(n=>F.includes(n.getName()??""))),U=t=>t.getImportDeclarations().some(e=>e.getNamedImports()[0]?.getName()==="getLayout"),H=(t,e,n)=>t.endsWith("embed")?`
import type { Params } from "next/dist/shared/lib/router/utils/route-matcher";
import { getData } from "../page";

type PageProps = Readonly<{
	params: Params;
}>;

const Page = ({ params }: PageProps) => {
	await getData(params, true);

	return null;
};
	
export default Page;`:t.includes("(individual-page-wrapper")?`
import OldPage from "@pages/${n}";
import { _generateMetadata } from "app/_utils";
import type { Params } from "next/dist/shared/lib/router/utils/route-matcher";
import PageWrapper from "@components/PageWrapperAppDir";
import { headers, cookies } from "next/headers";
import { buildLegacyCtx } from "@lib/buildLegacyCtx";

${e?'import { getLayout } from "@calcom/features/MainLayoutAppDir";':""}

export const generateMetadata = async () => await _generateMetadata(() => "", () => "");

type PageProps = Readonly<{
	params: Params;
}>;

const Page = async ({ params }: PageProps) => {
	const h = headers();
	const nonce = h.get("x-nonce") ?? undefined;
	
	const legacyCtx = buildLegacyCtx(headers(), cookies(), params);
	const props = await getData(legacyCtx);
	
	return (
		<PageWrapper ${e?"getLayout={getLayout} ":""} requiresLicense={false} nonce={nonce} themeBasis={null}>
			<OldPage {...props} />
		</PageWrapper>
	);
};
	
export default Page;`:`
import Page from "@pages/${n}";
import { _generateMetadata } from "app/_utils";

export const generateMetadata = async () => await _generateMetadata(() => "", () => "");

export default Page;`,$=(t,e,n,r)=>{let s=t.map(i=>i!=="pages"?i:n?"app/future/(individual-page-wrapper)":r?"app/future/(shared-page-wrapper)/(layout)":"app/future/(shared-page-wrapper)/(no-layout)");return e!=="index"&&s.push(e),s.join(g.sep)},V=async(t,e,n)=>{let r=(0,g.parse)(e),s=r.dir.split(g.sep),i=s.length>0&&s.lastIndexOf("pages")===s.length-1,d=r.name==="index";if(i&&d)return[];let l=await t.readFile(e);if(!i){let m=new a.default.Project({useInMemoryFileSystem:!0,skipFileDependencyResolution:!0,compilerOptions:{allowJs:!0}}).createSourceFile(e??"",l),c=W(m),u=U(m),P=$(s,r.name,c,u),y=`${r.dir.split("/pages/")[1]??""}/${r.name}`,S=H(P,u,y);return[{kind:"upsertFile",path:(0,g.format)({root:r.root,dir:P,ext:r.ext,name:"page"}),options:{...n,filePurpose:"ROUTE_PAGE",oldPath:e,oldData:C(S),legacyPageData:l}},{kind:"upsertFile",path:(0,g.format)({root:r.root,dir:r.dir,ext:r.ext,name:r.name}),options:{...n,filePurpose:"ORIGINAL_PAGE",oldPath:e,oldData:l}}]}return r.name==="_app"||r.name==="_document"?[{kind:"deleteFile",path:e}]:[]},J=async(t,e,n,r)=>{try{let s=r.filePurpose??null;if(s===null)return{kind:"noop"};let i=L.get(s)??null;return i===null?{kind:"noop"}:s==="ROUTE_PAGE"&&r.oldPath?j(t,e,r,s):s==="ORIGINAL_PAGE"&&r.oldPath&&r.oldData?G(String(r.oldPath),String(r.oldData)):{kind:"upsertData",path:e,data:i}}catch{return{kind:"noop"}}},z={includePatterns:["**/pages/**/*.{js,jsx,ts,tsx}"],excludePatterns:["**/node_modules/**","**/pages/api/**"],handleFile:V,handleData:J};0&&(module.exports={repomod});
