/*! @license
*/
"use strict";var i=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var m=(s,t)=>{for(var e in t)i(s,e,{get:t[e],enumerable:!0})},u=(s,t,e,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of c(t))!p.call(s,r)&&r!==e&&i(s,r,{get:()=>t[r],enumerable:!(n=l(t,r))||n.enumerable});return s};var f=s=>u(i({},"__esModule",{value:!0}),s);var x={};m(x,{default:()=>d});module.exports=f(x);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var h=class{j;path;argumentsMatch;hasDefault;constructor(t,e){this.j=t,this.path=e,this.argumentsMatch=this.checkArgumentContract()}checkArgumentContract(){let t=this.path.node;return t.arguments.length==0||t.arguments.length>2?!1:(this.hasDefault=t.arguments.length===2,!0)}transform(){if(!this.argumentsMatch)return;let t=this.path.node.arguments[0],e=t,n=!0;t?.type==="Literal"&&(e=this.j.identifier(`${t.value}`),n=!1);let r=this.path.node.callee,a=this.j.optionalMemberExpression(r.object,e,n);if(this.hasDefault){let o=this.path.node.arguments[1];this.path.replace(this.j.logicalExpression("??",a,o))}else this.path.replace(a)}},g=(s,t,e)=>{let n=t.jscodeshift,r=n(s.source);return r.find(n.CallExpression,{callee:{type:"MemberExpression",property:{type:"Identifier",name:"get"}}}).forEach(o=>new h(n,o).transform()),r.toSource(e)},d=g;
