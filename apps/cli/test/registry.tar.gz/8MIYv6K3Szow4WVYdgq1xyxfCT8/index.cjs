/*! @license
*/
"use strict";var i=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var a=Object.getOwnPropertyNames;var m=Object.prototype.hasOwnProperty;var p=(t,e)=>{for(var r in e)i(t,r,{get:e[r],enumerable:!0})},f=(t,e,r,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let o of a(e))!m.call(t,o)&&o!==r&&i(t,o,{get:()=>e[o],enumerable:!(n=c(e,o))||n.enumerable});return t};var u=t=>f(i({},"__esModule",{value:!0}),t);var b={};p(b,{default:()=>s});module.exports=u(b);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/jquery-event/index.js
 
MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

License URL: https://github.com/ember-codemods/ember-no-implicit-this-codemod/blob/master/LICENSE
*/function s(t,e){let r=e.jscodeshift,n=r(t.source);return n.find(r.MemberExpression,{object:{type:"MemberExpression",object:{name:"event"},property:{name:"originalEvent"}}}).replaceWith(o=>r.memberExpression(r.identifier(o.value.object.object.name),r.identifier(o.value.property.name),!1)),n.toSource()}
