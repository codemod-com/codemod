/*! @license
*/
"use strict";var u=Object.defineProperty;var b=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var E=Object.prototype.hasOwnProperty;var g=(o,n)=>{for(var e in n)u(o,e,{get:n[e],enumerable:!0})},k=(o,n,e,l)=>{if(n&&typeof n=="object"||typeof n=="function")for(let r of h(n))!E.call(o,r)&&r!==e&&u(o,r,{get:()=>n[r],enumerable:!(l=b(n,r))||l.enumerable});return o};var S=o=>k(u({},"__esModule",{value:!0}),o);var T={};g(T,{default:()=>y});module.exports=S(T);/*! @license

This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/deprecate-router-events/index.js

MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function y(o,n){let e=n.jscodeshift,l=e(o.source),r=(p,m,i)=>{let s=e.expressionStatement(e.callExpression(e.memberExpression(e.thisExpression(),e.identifier("_super"),!1),[e.identifier("...arguments")])),a=e.objectMethod("method",e.identifier("init"),[],e.blockStatement([s,m,i]));p.push(a)};return l.find(e.ExportDefaultDeclaration,{declaration:{callee:{object:{name:"Router"}}}}).forEach(p=>{let i=p.value.declaration.arguments[0].properties,s=i.findIndex(t=>t.key.name==="willTransition"),a;if(s>=0){let t=i[s].value?i[s].value.body.body:i[s].body.body;t.splice(0,1),a=e.expressionStatement(e.callExpression(e.memberExpression(e.thisExpression(),e.identifier("on"),!1),[e.literal("routeWillChange"),e.arrowFunctionExpression([e.identifier("transition")],e.blockStatement(t),!1)])),i.splice(i.findIndex(f=>f.key.name==="willTransition"),1)}let d=i.findIndex(t=>t.key.name==="didTransition"),c;if(d>=0){let t=i[d].value?i[d].value.body.body:i[d].body.body;t.splice(0,1),c=e.expressionStatement(e.callExpression(e.memberExpression(e.thisExpression(),e.identifier("on"),!1),[e.literal("routeDidChange"),e.arrowFunctionExpression([e.identifier("transition")],e.blockStatement(t),!1)])),i.splice(i.findIndex(f=>f.key.name==="didTransition"),1)}let x=i.filter(t=>t.key.name==="init")[0];x?x.body.body.push(a,c):r(i,a,c)}),l.toSource({quote:"single"})}
