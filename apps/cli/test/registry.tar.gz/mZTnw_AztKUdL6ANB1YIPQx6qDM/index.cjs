/*! @license
*/
"use strict";var n=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var a=Object.getOwnPropertyNames;var i=Object.prototype.hasOwnProperty;var f=(e,o)=>{for(var r in o)n(e,r,{get:o[r],enumerable:!0})},m=(e,o,r,t)=>{if(o&&typeof o=="object"||typeof o=="function")for(let s of a(o))!i.call(e,s)&&s!==r&&n(e,s,{get:()=>o[s],enumerable:!(t=l(o,s))||t.enumerable});return e};var p=e=>m(n({},"__esModule",{value:!0}),e);var x={};f(x,{default:()=>u});module.exports=p(x);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Changes to the original file: added options
*/var d=(e,o,r)=>{let t=o.jscodeshift,s=t(e.source);return s.find(t.CallExpression,{callee:{type:"Identifier",name:"fromJS"}}).replaceWith(c=>c.node.arguments),s.toSource(r)},u=d;
