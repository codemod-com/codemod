/*! @license
*/
"use strict";var s=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var a=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var d=(e,r)=>{for(var t in r)s(e,t,{get:r[t],enumerable:!0})},l=(e,r,t,n)=>{if(r&&typeof r=="object"||typeof r=="function")for(let o of a(r))!c.call(e,o)&&o!==t&&s(e,o,{get:()=>r[o],enumerable:!(n=u(r,o))||n.enumerable});return e};var m=e=>l(s({},"__esModule",{value:!0}),e);var h={};d(h,{default:()=>I});module.exports=m(h);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added TypeScript, dirty flag, nullability checks
*/function p(e,r,t){let n=r.jscodeshift,o=n(e.source),f=!1;if(o.find(n.ImportDeclaration,{source:{value:"react-router"}}).forEach(i=>{i.value.source.value="react-router-dom",f=!0}),!!f)return o.toSource(t)}var I=p;
