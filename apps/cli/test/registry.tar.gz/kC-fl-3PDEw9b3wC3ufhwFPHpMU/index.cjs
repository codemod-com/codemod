/*! @license
*/
"use strict";var i=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var l=(n,o)=>{for(var r in o)i(n,r,{get:o[r],enumerable:!0})},p=(n,o,r,e)=>{if(o&&typeof o=="object"||typeof o=="function")for(let t of d(o))!f.call(n,t)&&t!==r&&i(n,t,{get:()=>o[t],enumerable:!(e=u(o,t))||e.enumerable});return n};var j=n=>p(i({},"__esModule",{value:!0}),n);var g={};l(g,{default:()=>I});module.exports=j(g);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function x(n,o,r){let e=o.jscodeshift,t=e(n.source);if(t.find(e.ImportDeclaration,{source:{value:"react-router-dom-v5-compat"}}).length)return;let m=e.importDeclaration([e.importSpecifier(e.identifier("CompatRouter"))],e.literal("react-router-dom-v5-compat"));return t.get().value.program.body.unshift(m),t.find(e.JSXElement,{openingElement:{name:{name:"BrowserRouter"}}}).forEach(s=>{let a=s.value.children,c=e.jsxElement(e.jsxOpeningElement(e.jsxIdentifier("CompatRouter"),[],!1),e.jsxClosingElement(e.jsxIdentifier("CompatRouter")),a);s.value.children=[e.jsxText(`
  `),c,e.jsxText(`
`)]}),t.toSource(r)}var I=x;
