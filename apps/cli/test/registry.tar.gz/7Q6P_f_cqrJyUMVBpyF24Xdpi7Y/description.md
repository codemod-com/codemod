# Hash Router

## Description

Run this codemod to replace `Router` using `hashHistory` to `HashRouter` in v4.