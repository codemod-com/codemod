/*! @license
*/
"use strict";var t=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var f=Object.getOwnPropertyNames;var m=Object.prototype.hasOwnProperty;var E=(i,r)=>{for(var e in r)t(i,e,{get:r[e],enumerable:!0})},p=(i,r,e,n)=>{if(r&&typeof r=="object"||typeof r=="function")for(let s of f(r))!m.call(i,s)&&s!==e&&t(i,s,{get:()=>r[s],enumerable:!(n=c(r,s))||n.enumerable});return i};var u=i=>p(t({},"__esModule",{value:!0}),i);var x={};E(x,{default:()=>o});module.exports=u(x);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/jquery-apis/index.js

MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

License URL: https://github.com/ember-codemods/ember-no-implicit-this-codemod/blob/master/LICENSE
 */function o(i,r){let e=r.jscodeshift,n=e(i.source);return n.find(e.CallExpression,{callee:{object:{callee:{object:{type:"ThisExpression"},property:{name:"$"}}}}}).forEach(()=>{}).replaceWith(s=>{let a=s.value.callee.object.arguments.length>0,l;return a?l=e.callExpression(e.memberExpression(e.callExpression(e.memberExpression(e.memberExpression(e.thisExpression(),e.identifier("element"),!1),e.identifier("querySelectorAll")),s.value.callee.object.arguments),e.identifier("forEach"),!1),[e.arrowFunctionExpression([e.identifier("el")],e.callExpression(e.memberExpression(e.identifier("el"),e.identifier("addEventListener"),!1),s.value.arguments),!1)]):l=e.callExpression(e.memberExpression(e.memberExpression(e.thisExpression(),e.identifier("element"),!1),e.identifier("addEventListener"),!1),s.value.arguments),l}),n.toSource()}
