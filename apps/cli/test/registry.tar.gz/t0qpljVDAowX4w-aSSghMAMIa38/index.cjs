/*! @license
*/
"use strict";var a=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var u=(o,e)=>{for(var n in e)a(o,n,{get:e[n],enumerable:!0})},d=(o,e,n,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let t of p(e))!f.call(o,t)&&t!==n&&a(o,t,{get:()=>e[t],enumerable:!(r=c(e,t))||r.enumerable});return o};var m=o=>d(a({},"__esModule",{value:!0}),o);var y={};u(y,{default:()=>s});module.exports=m(y);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/cp-volatile/index.js

MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

License URL: https://github.com/ember-codemods/ember-no-implicit-this-codemod/blob/master/LICENSE
 */function s(o,e){let n=e.jscodeshift,r=n(o.source);return r.find(n.CallExpression,{callee:{type:"MemberExpression",object:{callee:{name:"computed"}},property:{name:"volatile"}}}).map(t=>t.parentPath).replaceWith(t=>{let i=t.value.value.callee.object.arguments.find(l=>l.type==="FunctionExpression").body;return n.property("get",n.identifier(t.value.key.name),n.functionExpression(n.identifier(t.value.key.name),[],i,!1,!1))}),r.toSource()}
