# Add Exact Prop

## Description

Add `exact` prop to all instances of `Route` component.