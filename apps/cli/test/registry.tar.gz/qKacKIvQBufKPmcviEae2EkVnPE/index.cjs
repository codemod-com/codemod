/*! @license
*/
"use strict";var o=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var m=Object.prototype.hasOwnProperty;var d=(e,t)=>{for(var i in t)o(e,i,{get:t[i],enumerable:!0})},h=(e,t,i,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of c(t))!m.call(e,n)&&n!==i&&o(e,n,{get:()=>t[n],enumerable:!(r=l(t,n))||r.enumerable});return e};var p=e=>h(o({},"__esModule",{value:!0}),e);var g={};d(g,{default:()=>E});module.exports=p(g);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function x(e,t,i){let r=t.jscodeshift,n=r(e.source),f=!1;if(n.find(r.JSXElement,{openingElement:{name:{name:"Route"}}}).forEach(u=>{let s=u.value.openingElement.attributes;!s||s.filter(a=>"name"in a?a.name.name==="exact":!1).length>0||(s.unshift(r.jsxAttribute(r.jsxIdentifier("exact"),null)),f=!0)}),!!f)return n.toSource(i)}var E=x;
