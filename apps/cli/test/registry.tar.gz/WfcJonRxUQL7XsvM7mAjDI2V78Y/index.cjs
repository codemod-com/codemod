/*! @license
*/
"use strict";var i=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var u=Object.prototype.hasOwnProperty;var m=(e,r)=>{for(var o in r)i(e,o,{get:r[o],enumerable:!0})},d=(e,r,o,s)=>{if(r&&typeof r=="object"||typeof r=="function")for(let t of p(r))!u.call(e,t)&&t!==o&&i(e,t,{get:()=>r[t],enumerable:!(s=f(r,t))||s.enumerable});return e};var y=e=>d(i({},"__esModule",{value:!0}),e);var g={};m(g,{default:()=>x});module.exports=y(g);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var E=e=>e.arguments.length===1&&e.arguments[0]&&e.arguments[0].type==="ObjectExpression",j=(e,r)=>{let o=r.jscodeshift,s=o(e.source);return s.find(o.CallExpression,{callee:{type:"Identifier",name:"fromJS"}}).forEach(a=>{if(E(a.node)){let c=a.node.arguments[0];c.properties.forEach(l=>{let n=l;n.value.type==="Literal"&&n.value.raw||(n.value=o.callExpression(o.identifier("fromJS"),[n.value]))}),a.replace(c)}}),s.toSource()},x=j;
