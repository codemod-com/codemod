/*! @license
*/
"use strict";var a=Object.defineProperty;var g=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var I=Object.prototype.hasOwnProperty;var S=(t,r)=>{for(var e in r)a(t,e,{get:r[e],enumerable:!0})},v=(t,r,e,i)=>{if(r&&typeof r=="object"||typeof r=="function")for(let o of d(r))!I.call(t,o)&&o!==e&&a(t,o,{get:()=>r[o],enumerable:!(i=g(r,o))||i.enumerable});return t};var x=t=>v(a({},"__esModule",{value:!0}),t);var h={};S(h,{default:()=>f});module.exports=x(h);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var c="ImageResponse";function f(t,r){let e=r.jscodeshift,i=!1;if(t.source=e(t.source).find(e.ImportDeclaration,{source:{value:"next/server"}}).forEach(o=>{let s=o.node.specifiers,m=s.filter(n=>n.local.name===c),l=s.filter(n=>n.local.name!==c);if(m.length>0){let n=e.importDeclaration(m,e.stringLiteral("next/og"));o.insertBefore(n),i=!0}if(l.length>0){let n=s.filter(u=>u.local.name!==c),p=e.importDeclaration(n,e.stringLiteral("next/server"));o.insertBefore(p),i=!0}e(o).remove()}).toSource(),!!i)return t.source}
