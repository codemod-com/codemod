/*! @license
*/
"use strict";var o=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var m=(s,e)=>{for(var t in e)o(s,t,{get:e[t],enumerable:!0})},l=(s,e,t,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let n of h(e))!p.call(s,n)&&n!==t&&o(s,n,{get:()=>e[n],enumerable:!(r=c(e,n))||r.enumerable});return s};var u=s=>l(o({},"__esModule",{value:!0}),s);var d={};m(d,{default:()=>j});module.exports=u(d);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var a=class{j;path;argumentsMatch;constructor(e,t){this.j=e,this.path=t,this.argumentsMatch=this.checkArgumentContract()}checkArgumentContract(){return this.path.node.arguments.length===1}transform(){if(!this.argumentsMatch)return;let e=this.path.node.callee.object,t=this.path.node.arguments[0],r=[this.j.spreadElement(t)];t.type==="ObjectExpression"&&(r=[...t.properties]),this.path.replace(this.j.objectExpression([this.j.spreadElement(e),...r]))}},f=(s,e,t)=>{let r=e.jscodeshift,n=r(s.source);return n.find(r.CallExpression,{callee:{type:"MemberExpression",property:{type:"Identifier",name:"merge"}}}).forEach(i=>new a(r,i).transform()),n.toSource(t)},j=f;
