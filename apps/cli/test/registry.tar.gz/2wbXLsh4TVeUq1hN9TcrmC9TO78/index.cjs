/*! @license
*/
"use strict";var A=Object.defineProperty;var b=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var C=Object.prototype.hasOwnProperty;var E=(n,r)=>{for(var e in r)A(n,e,{get:r[e],enumerable:!0})},k=(n,r,e,s)=>{if(r&&typeof r=="object"||typeof r=="function")for(let y of h(r))!C.call(n,y)&&y!==e&&A(n,y,{get:()=>r[y],enumerable:!(s=b(r,y))||s.enumerable});return n};var D=n=>k(A({},"__esModule",{value:!0}),n);var V={};E(V,{default:()=>P,parser:()=>R});module.exports=D(V);/*! @license

ISC License

Copyright (c) 2023, Gonzalo D'Elia

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/var R="tsx",F=n=>n.type==="Identifier",g=n=>n.type==="TSTypeReference",N=n=>n.type==="ObjectPattern",O=n=>n.type==="ArrowFunctionExpression";function P(n,r){let e=r.j;function s(t){let o;if(F(t.node.id)&&(e.TSIntersectionType.check(t.node.id.typeAnnotation.typeAnnotation)?o=t.node.id.typeAnnotation.typeAnnotation?.types[0]:o=t.node.id.typeAnnotation.typeAnnotation),!o?.typeParameters)return;let c=L(e,o),a=e.CallExpression.check(t.node.init)?t.node.init.arguments[0]:t.node.init,p=a?.params?.length,i=[];if(p)i=a.params.slice(1,p);else return;let f=a.params[0],l;if(F(f)&&(l=e.identifier.from({...f,typeAnnotation:c})),N(f)){let{properties:d,...x}=f;l=e.objectPattern.from({...x,properties:d.map(({loc:j,...T})=>{let S=T.type.slice(0,1).toLowerCase()+T.type.slice(1);if(S==="restElement"){let I=T;return e.restProperty.from({argument:I.argument})}return e[S].from({...T})}),typeAnnotation:c})}let m;O(a)?m=e.arrowFunctionExpression.from({...a,params:[l,...i]}):m=e.functionExpression.from({...a,params:[l,...i]});let u;e.CallExpression.check(t.node.init)?u=e.variableDeclarator.from({...t.node,init:{...t.node.init,arguments:[m]}}):u=e.variableDeclarator.from({...t.node,init:m}),t.replace(u)}function y(t){let{id:o,...c}=t.node,{typeAnnotation:a,...p}=o,i=e.identifier.from({...p}),f=e.variableDeclarator.from({...c,id:i});t.replace(f)}try{let t=e(n.source),o=!1,c=t.find(e.VariableDeclarator,a=>{let p=a?.id,i;e.TSIntersectionType.check(p?.typeAnnotation?.typeAnnotation)?i=p.typeAnnotation.typeAnnotation.types[0].typeName:i=p?.typeAnnotation?.typeAnnotation?.typeName;let f=p?.typeAnnotation?.typeAnnotation?.typeParameters?.type,l=d=>["FC","FunctionComponent"].includes(d),m=i?.left?.name==="React"&&l(i?.right?.name)||l(i?.name),u=i?.left?.name==="React"&&i?.right?.name==="SFC"||i?.name==="SFC";return(m||u)&&(["TSQualifiedName","TSTypeParameterInstantiation"].includes(f)||!p?.typeAnnotation?.typeAnnotation?.typeParameters)}).forEach(a=>{o=!0,s(a),y(a)}).toSource();return o?c:null}catch(t){console.log(t)}}function L(n,r){let e=r.typeParameters.params[0],s;if(g(e)){let{loc:t,...o}=e;s=n.tsTypeReference.from({...o})}else if(n.TSIntersectionType.check(e)){let{loc:t,...o}=e;s=n.tsIntersectionType.from({...o,types:o.types.map(c=>w(n,c))})}else{let o=e.members.map(c=>w(n,c));s=n.tsTypeLiteral.from({members:o})}return n.tsTypeAnnotation.from({typeAnnotation:s})}function w(n,{loc:r,...e}){let s=e.type.slice(0,2).toLowerCase()+e.type.slice(2);return n[s].from({...e})}0&&(module.exports={parser});
