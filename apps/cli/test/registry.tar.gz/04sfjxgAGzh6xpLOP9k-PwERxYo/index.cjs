/*! @license
*/
"use strict";var c=Object.defineProperty;var m=Object.getOwnPropertyDescriptor;var s=Object.getOwnPropertyNames;var l=Object.prototype.hasOwnProperty;var u=(r,t)=>{for(var a in t)c(r,a,{get:t[a],enumerable:!0})},d=(r,t,a,e)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of s(t))!l.call(r,o)&&o!==a&&c(r,o,{get:()=>t[o],enumerable:!(e=m(t,o))||e.enumerable});return r};var f=r=>d(c({},"__esModule",{value:!0}),r);var b={};u(b,{default:()=>p});module.exports=f(b);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added the options parameter
*/function p(r,t,a){let e=t.jscodeshift,o=e(r.source);if(!o.find(e.ImportDeclaration,{source:{value:"react-router-dom-v5-compat"}}).length){let i=e.importDeclaration([e.importSpecifier(e.identifier("useParams"))],e.literal("react-router-dom-v5-compat"));o.get().value.program.body.unshift(i)}return o.find(e.VariableDeclarator,{init:{object:{name:"props"},property:{name:"match"}}}).forEach(i=>{let n=e.variableDeclaration("const",[e.variableDeclarator(e.identifier("params"),e.callExpression(e.identifier("useParams"),[]))]);i.parent.replace(n)}),o.toSource(a)}
