# Hash Router

## Description

Replace `IndexRoute` with `Route` having `exact` prop set to `true`.