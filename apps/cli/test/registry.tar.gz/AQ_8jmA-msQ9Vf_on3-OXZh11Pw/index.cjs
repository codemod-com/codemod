/*! @license
*/
"use strict";var u=Object.defineProperty;var a=Object.getOwnPropertyDescriptor;var l=Object.getOwnPropertyNames;var m=Object.prototype.hasOwnProperty;var d=(t,e)=>{for(var o in e)u(t,o,{get:e[o],enumerable:!0})},c=(t,e,o,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let i of l(e))!m.call(t,i)&&i!==o&&u(t,i,{get:()=>e[i],enumerable:!(n=a(e,i))||n.enumerable});return t};var p=t=>c(u({},"__esModule",{value:!0}),t);var I={};d(I,{default:()=>x});module.exports=p(I);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function j(t,e,o){let n=e.jscodeshift,i=n(t.source),r=!1;if(i.find(n.JSXElement,{openingElement:{name:{name:"IndexRoute"}}}).forEach(s=>{"name"in s.value.openingElement.name&&(s.value.openingElement.name.name="Route",r=!0);let f=s.value.openingElement.attributes;f&&(f.unshift(n.jsxAttribute(n.jsxIdentifier("path"),n.literal("/"))),f.unshift(n.jsxAttribute(n.jsxIdentifier("exact"),null)),r=!0)}),!!r)return i.toSource(o)}var x=j;
