/*! @license
*/
"use strict";var l=Object.defineProperty;var t=Object.getOwnPropertyDescriptor;var i=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var m=(a,e)=>{for(var o in e)l(a,o,{get:e[o],enumerable:!0})},u=(a,e,o,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let r of i(e))!f.call(a,r)&&r!==o&&l(a,r,{get:()=>e[r],enumerable:!(n=t(e,r))||n.enumerable});return a};var g=a=>u(l({},"__esModule",{value:!0}),a);var p={};m(p,{default:()=>s});module.exports=g(p);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/deprecate-merge/index.js

MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function s(a,e){let o=e.jscodeshift,n=o(a.source);return n.find(o.CallExpression,{callee:{name:"merge"}}).forEach(r=>{r.value.callee.name="assign"}),n.find(o.ImportDeclaration,{specifiers:[{local:{name:"merge"}}]}).forEach(r=>{r.value.specifiers.filter(c=>c.local.name==="merge").forEach(c=>{c.local.name="assign"})}),n.toSource()}
