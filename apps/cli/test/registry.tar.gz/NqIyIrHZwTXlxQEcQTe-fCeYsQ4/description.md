# Replace API Routes

## Description

Replaces API Routes with Route Handlers.
