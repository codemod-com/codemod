/*! @license
*/
"use strict";var n=Object.defineProperty;var i=Object.getOwnPropertyDescriptor;var l=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var a=(o,e)=>{for(var s in e)n(o,s,{get:e[s],enumerable:!0})},f=(o,e,s,t)=>{if(e&&typeof e=="object"||typeof e=="function")for(let r of l(e))!p.call(o,r)&&r!==s&&n(o,r,{get:()=>e[r],enumerable:!(t=i(e,r))||t.enumerable});return o};var m=o=>f(n({},"__esModule",{value:!0}),o);var b={};a(b,{default:()=>x});module.exports=m(b);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var d=(o,e,s)=>{let t=e.jscodeshift,r=t(o.source);return r.find(t.CallExpression,{callee:{type:"MemberExpression",property:{type:"Identifier",name:"toJS"}}}).replaceWith(c=>c.node.callee.object),r.toSource(s)},x=d;
