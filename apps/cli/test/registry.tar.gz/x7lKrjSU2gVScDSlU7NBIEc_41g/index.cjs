/*! @license
*/
"use strict";var f=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var v=Object.getOwnPropertyNames;var y=Object.prototype.hasOwnProperty;var k=(n,e)=>{for(var l in e)f(n,l,{get:e[l],enumerable:!0})},d=(n,e,l,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let a of v(e))!y.call(n,a)&&a!==l&&f(n,a,{get:()=>e[a],enumerable:!(o=c(e,a))||o.enumerable});return n};var g=n=>d(f({},"__esModule",{value:!0}),n);var I={};k(I,{default:()=>x});module.exports=g(I);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function p(n,e,l){let o=e.jscodeshift,a=o(n.source),m=!1;if(a.find(o.CallExpression,{callee:{name:"matchPath"}}).forEach(u=>{let i=u.value.arguments;if(i[0]&&i[1]&&"properties"in i[1]){let[t]=i[1].properties.filter(s=>"key"in s&&"name"in s.key?s.key.name==="exact":!1);t&&"key"in t&&"name"in t.key&&"value"in t&&"value"in t.value&&(t.key.name="caseSensitive",t.value.value=!1);let[r]=i[1].properties.filter(s=>"key"in s&&"name"in s.key?s.key.name==="strict":!1);r&&"key"in r&&"name"in r.key&&"value"in r&&"value"in r.value&&(r.key.name="end",r.value.value=!0),u.value.arguments=[],u.value.arguments[0]=i[1],u.value.arguments[1]=i[0],m=!0}}),!!m)return a.toSource(l)}var x=p;
