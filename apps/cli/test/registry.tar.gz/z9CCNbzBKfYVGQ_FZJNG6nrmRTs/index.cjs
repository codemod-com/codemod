/*! @license
*/
"use strict";var J=Object.defineProperty;var j=Object.getOwnPropertyDescriptor;var D=Object.getOwnPropertyNames;var M=Object.prototype.hasOwnProperty;var V=(r,e)=>{for(var a in e)J(r,a,{get:e[a],enumerable:!0})},K=(r,e,a,t)=>{if(e&&typeof e=="object"||typeof e=="function")for(let p of D(e))!M.call(r,p)&&p!==a&&J(r,p,{get:()=>e[p],enumerable:!(t=j(e,p))||t.enumerable});return r};var P=r=>K(J({},"__esModule",{value:!0}),r);var L={};V(L,{default:()=>q});module.exports=P(L);/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/ast.js

Changes: move the code from JavaScript to TypeScript
*/var T=function(r,e,a){return r.property("init",r.identifier(e),a)},A=function(r,e){return r.objectExpression(Object.entries(e).map(([a,t])=>T(r,a,t)))},X=function(r,e){return e.value?.value?.type==="JSXExpressionContainer"?e.value.value.expression:e.value.value},x=(r,e,a,t=[])=>{let p=r.find(e.VariableDeclarator,{init:{type:"Identifier",name:a}});return p.length>0&&p.forEach(b=>{t.push(b.node.id.name),x(r,e,b.node.id.name,t)}),t};/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/config.js

Changes: move the code from JavaScript to TypeScript
*/var k={quote:"single"};/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/v5-props-changed-migration.js

Changes to the original file: added TypeScript support
*/function R(r){return(r||"").split(",").filter(e=>e).map(e=>e.trim())}var w={AutoComplete:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},Cascader:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},Select:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},TreeSelect:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},TimePicker:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},"TimePicker.RangePicker":{dropdownClassName:{action:"rename",replacer:"popupClassName"}},DatePicker:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},"DatePicker.RangePicker":{dropdownClassName:{action:"rename",replacer:"popupClassName"}},Mentions:{dropdownClassName:{action:"rename",replacer:"popupClassName"}},Drawer:{visible:{action:"rename",replacer:"open"},className:{action:"rename",replacer:"rootClassName"},style:{action:"rename",replacer:"rootStyle"}},Modal:{visible:{action:"rename",replacer:"open"}},Dropdown:{visible:{action:"rename",replacer:"open"}},Tooltip:{visible:{action:"rename",replacer:"open"}},Tag:{visible:{action:"remove"}},Slider:{tipFormatter:{action:"rename",replacer:"tooltip.formatter"},tooltipPlacement:{action:"rename",replacer:"tooltip.placement"},tooltipVisible:{action:"rename",replacer:"tooltip.open"}},Table:{filterDropdownVisible:{action:"rename",replacer:"filterDropdownOpen"}}},F=(r,e,a)=>{let t=e.jscodeshift,p=t(r.source),b=R(a.antdPkgNames||"antd"),v=Object.keys(w).map(s=>s.split("."));function g(s,o){let c=!1;return Object.keys(o).forEach(l=>{s.find(t.JSXAttribute,{name:{type:"JSXIdentifier",name:l}}).filter(n=>t.JSXOpeningElement.check(n.parent.node)&&s.paths().includes(n.parent.parent)).forEach(n=>{let{action:S,replacer:m}=o[l];if(S==="rename"&&m)if(m.includes(".")){let u=X(t,n);n.parent.node.attributes=n.parent.node.attributes.filter(y=>y.name.name!==l),c=!0;let[f,i]=m.split("."),d=t(n.parent.parent).find(t.JSXAttribute,{name:{type:"JSXIdentifier",name:f}});if(d.length===0){let y=t.jsxAttribute(t.jsxIdentifier(f),t.jsxExpressionContainer(A(t,{[i]:u})));n.parent.node.attributes.push(y)}else d.paths()[0].value.value.expression.properties.push(T(t,i,u))}else n.node.name=m,c=!0;if(S==="remove"){let u=n.value.value;n.value?.value?.type==="JSXExpressionContainer"&&(u=n.value.value.expression),n.parent.node.attributes=n.parent.node.attributes.filter(i=>i.name.name!==l),c=!0;let f=u?t.conditionalExpression(u,n.parent.parent.node,t.nullLiteral()):null;if(f)if(["JSXElement","JSXFragment"].includes(n.parent.parent.parent.node.type)){let i=n.parent.parent.parent.node.children.findIndex(d=>d===n.parent.parent.node);i>-1&&n.parent.parent.parent.node.children.splice(i,1,t.jsxExpressionContainer(f))}else["ReturnStatement"].includes(n.parent.parent.parent.node.type)&&(n.parent.parent.parent.node.argument=f)}})}),c}function I(s,o){let c=!1;return o.find(s.Identifier).filter(l=>v.map(n=>n[0]).includes(l.node.name)&&l.parent.node.type==="ImportSpecifier"&&b.includes(l.parent.parent.node.source.value)).forEach(l=>{let n=l.parent.node.imported.name,S=l.parent.node.local.name,m=w[n],u=o.findJSXElements(S);g(u,m)&&(c=!0);let f=v.find(d=>d[0]===n&&d[1]),[,i]=f||[];if(i){let d=o.find(s.JSXElement,{openingElement:{name:{type:"JSXMemberExpression",object:{type:"JSXIdentifier",name:S},property:{type:"JSXIdentifier",name:i}}}});g(d,m)&&(c=!0),o.find(s.VariableDeclarator,{init:{type:"Identifier",name:S}}).forEach(y=>{y.node.id.properties.filter(C=>C.key.name===i).map(C=>C.value?.name||C.key.name).forEach(C=>{x(o,s,C,[C]).forEach(E=>{let O=o.findJSXElements(E);g(O,m)&&(c=!0)})})}),o.find(s.VariableDeclarator,{init:{type:"MemberExpression",object:{type:"Identifier",name:S},property:{type:"Identifier",name:i}}}).forEach(y=>{let N=y.node.id.name;x(o,s,N,[N]).forEach(h=>{let E=o.findJSXElements(h);g(E,m)&&(c=!0)})})}}),c}return I(t,p)||!1?p.toSource(a.printOptions||k):null},q=F;
