/*! @license
*/
"use strict";var o=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var l=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var p=(t,e)=>{for(var r in e)o(t,r,{get:e[r],enumerable:!0})},d=(t,e,r,i)=>{if(e&&typeof e=="object"||typeof e=="function")for(let n of l(e))!c.call(t,n)&&n!==r&&o(t,n,{get:()=>e[n],enumerable:!(i=u(e,n))||i.enumerable});return t};var h=t=>d(o({},"__esModule",{value:!0}),t);var j={};p(j,{default:()=>g});module.exports=h(j);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function b(t,e,r){let i=e.jscodeshift,n=i(t.source),f=!1;if(n.find(i.JSXElement,{openingElement:{name:{name:"Redirect"}}}).forEach(m=>{let s=m.value.openingElement;"name"in s.name&&(s.name.name="Navigate"),s.attributes?.filter(a=>"name"in a?a.name.name==="push":!1).length??0>0?s.attributes=s.attributes?.filter(a=>"name"in a?a.name.name!=="push":!1)??[]:s.attributes&&s.attributes.push(i.jsxAttribute(i.jsxIdentifier("replace")))}),!!f)return n.toSource(r)}var g=b;
