/*! @license
*/
"use strict";var n=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var m=Object.prototype.hasOwnProperty;var d=(o,r)=>{for(var t in r)n(o,t,{get:r[t],enumerable:!0})},u=(o,r,t,e)=>{if(r&&typeof r=="object"||typeof r=="function")for(let s of p(r))!m.call(o,s)&&s!==t&&n(o,s,{get:()=>r[s],enumerable:!(e=f(r,s))||e.enumerable});return o};var x=o=>u(n({},"__esModule",{value:!0}),o);var E={};d(E,{default:()=>i});module.exports=x(E);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added options
*/function i(o,r,t){let e=r.jscodeshift,s=e(o.source);return s.find(e.CallExpression,{callee:{object:{callee:{name:"Map"}},property:{name:"toArray"}}}).forEach(a=>{let l=a.value.callee.object.arguments,c=e.callExpression(e.memberExpression(e.callExpression(e.memberExpression(e.callExpression(e.identifier("Map"),l),e.identifier("toList"),!1),[]),e.identifier("toArray"),!1),[]);e(a).replaceWith(c)}),s.toSource(t)}
