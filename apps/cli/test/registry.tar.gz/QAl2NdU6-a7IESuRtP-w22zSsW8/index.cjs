/*! @license
*/
"use strict";var l=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var g=(i,n)=>{for(var r in n)l(i,r,{get:n[r],enumerable:!0})},A=(i,n,r,e)=>{if(n&&typeof n=="object"||typeof n=="function")for(let t of p(n))!c.call(i,t)&&t!==r&&l(i,t,{get:()=>n[t],enumerable:!(e=h(n,t))||e.enumerable});return i};var x=i=>A(l({},"__esModule",{value:!0}),i);var v={};g(v,{default:()=>j});module.exports=x(v);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function E(i,n,r){let e=n.jscodeshift,t=e(i.source),s=!1;if(t.find(e.JSXElement,{openingElement:{name:{name:"RedwoodProvider"}}}).forEach(u=>{if(u.value.children?.filter(o=>"openingElement"in o&&"name"in o.openingElement.name?o.openingElement.name.name==="AuthProvider":!1).length)return;let a=e.jsxElement(e.jsxOpeningElement(e.jsxIdentifier("AuthProvider"),[],!1),e.jsxClosingElement(e.jsxIdentifier("AuthProvider")),u.value.children);if(u.value.children=[e.jsxText(`
  `),a,e.jsxText(`
  `)],t.find(e.JSXElement,{openingElement:{name:{name:"RedwoodApolloProvider"}}}).forEach(o=>{let m=e.jsxAttribute(e.jsxIdentifier("useAuth"),e.jsxExpressionContainer(e.identifier("useAuth"))),{attributes:d}=o.value.openingElement;d&&(d.push(m),s=!0)}),t.find(e.ImportDeclaration,{source:{value:"./auth"}}).length>0)return;let f=e.importDeclaration([e.importSpecifier(e.identifier("AuthProvider"),e.identifier("AuthProvider")),e.importSpecifier(e.identifier("useAuth"),e.identifier("useAuth"))],e.stringLiteral("./auth"));t.get().value.program.body.unshift(f),s=!0}),!!s)return t.toSource(r)}var j=E;
