# Remove With Props

## Description

