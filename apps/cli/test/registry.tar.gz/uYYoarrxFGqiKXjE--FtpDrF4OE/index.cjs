/*! @license
*/
"use strict";var f=Object.defineProperty;var j=Object.getOwnPropertyDescriptor;var v=Object.getOwnPropertyNames;var g=Object.prototype.hasOwnProperty;var E=(t,n)=>{for(var s in n)f(t,s,{get:n[s],enumerable:!0})},I=(t,n,s,e)=>{if(n&&typeof n=="object"||typeof n=="function")for(let r of v(n))!g.call(t,r)&&r!==s&&f(t,r,{get:()=>n[r],enumerable:!(e=j(n,r))||e.enumerable});return t};var b=t=>I(f({},"__esModule",{value:!0}),t);var S={};E(S,{default:()=>P});module.exports=b(S);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function y(t,n,s){let e=n.jscodeshift,r=e(t.source),p=!1;if(r.find(e.VariableDeclarator,{init:{callee:{name:"withProps"}}}).forEach(a=>{let c="name"in a.value.id?a.value.id.name:null,u=a.value.init&&"arguments"in a.value.init?a.value.init.arguments[1]:null,d=u&&"properties"in u?u.properties.map(i=>"key"in i&&"name"in i.key?i.key.name:null).filter(i=>typeof i=="string"):[];c&&(r.find(e.JSXElement,{openingElement:{name:{name:"Route"}}}).filter(i=>(i.value.openingElement.attributes??[]).filter(o=>"name"in o&&o.name.name==="component"&&"value"in o&&o.value?.type==="JSXExpressionContainer"&&"name"in o.value.expression&&o.value.expression.name===c).length>0).forEach(i=>{let[l]=i.value.openingElement.attributes?.filter(m=>"name"in m?m.name.name==="component":!1)??[];if(!l||!("name"in l))return;let o=d.map(m=>e.jsxAttribute(e.jsxIdentifier(m),e.jsxExpressionContainer(e.identifier("title")))),x=e.jsxElement(e.jsxOpeningElement(e.jsxIdentifier("Dashboard"),[...o,e.jsxSpreadAttribute(e.jsxIdentifier("props"))],!0),null,[]);l.name.name="render",l.value=e.jsxExpressionContainer(e.arrowFunctionExpression([e.jsxIdentifier("props")],e.blockStatement([e.returnStatement(x)]),!0))}),e(a.parentPath.parentPath).remove(),p=!0)}),!!p)return r.toSource(s)}var P=y;
