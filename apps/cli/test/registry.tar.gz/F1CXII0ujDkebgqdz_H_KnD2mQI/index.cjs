/*! @license
*/
"use strict";var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var a=Object.getOwnPropertyNames;var h=Object.prototype.hasOwnProperty;var m=(t,n)=>{for(var s in n)r(t,s,{get:n[s],enumerable:!0})},u=(t,n,s,e)=>{if(n&&typeof n=="object"||typeof n=="function")for(let i of a(n))!h.call(t,i)&&i!==s&&r(t,i,{get:()=>n[i],enumerable:!(e=d(n,i))||e.enumerable});return t};var j=t=>u(r({},"__esModule",{value:!0}),t);var S={};m(S,{default:()=>E});module.exports=j(S);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function x(t,n,s){let e=n.jscodeshift,i=e(t.source),o=!1;if(i.find(e.JSXElement,{openingElement:{name:{name:"Router"}}}).forEach(f=>{if(i.findJSXElements("Switch").length>0)return;let l=f.value.children,c=e.jsxElement(e.jsxOpeningElement(e.jsxIdentifier("Switch"),[],!1),e.jsxClosingElement(e.jsxIdentifier("Switch")),l);f.value.children=[e.jsxText(`
  `),c,e.jsxText(`
`)],o=!0}),!!o)return i.toSource(s)}var E=x;
