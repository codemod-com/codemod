/*! @license
*/
"use strict";var d=Object.defineProperty;var P=Object.getOwnPropertyDescriptor;var k=Object.getOwnPropertyNames;var C=Object.prototype.hasOwnProperty;var F=(e,t)=>{for(var a in t)d(e,a,{get:t[a],enumerable:!0})},M=(e,t,a,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of k(t))!C.call(e,n)&&n!==a&&d(e,n,{get:()=>t[n],enumerable:!(o=P(t,n))||o.enumerable});return e};var S=e=>M(d({},"__esModule",{value:!0}),e);var L={};F(L,{USE_COMPAT_SEARCH_PARAMS_HOOK_CONTENT:()=>u,repomod:()=>b});module.exports=S(L);var u=`
import { ReadonlyURLSearchParams, useParams, useSearchParams } from "next/navigation";

export const useCompatSearchParams = () => {
  const _searchParams = useSearchParams() ?? new URLSearchParams();
  const params = useParams() ?? {};

  const searchParams = new URLSearchParams(_searchParams.toString());
  Object.getOwnPropertyNames(params).forEach((key) => {
    searchParams.delete(key);

    const param = params[key];
    const paramArr = typeof param === "string" ? param.split("/") : param;

    paramArr.forEach((p) => {
      searchParams.append(key, p);
    });
  });

  return new ReadonlyURLSearchParams(searchParams);
};

`,x=(e,t)=>(t.replaceWith(e.callExpression(e.identifier("useCompatSearchParams"),[])),[!0,[]]),E=(e,t,a)=>{let o=[];return t.find(e.CallExpression,{callee:{type:"Identifier",name:"useSearchParams"}}).forEach(n=>{o.push([x,e(n),a])}),[!1,o]},g=(e,t,{hookModuleSpecifier:a})=>(t.find(e.Program).forEach(o=>{o.value.body.unshift(e.importDeclaration([e.importSpecifier(e.identifier("useCompatSearchParams"))],e.literal(a)))}),[!1,[]]),w=(e,t)=>{let a=!1;return t.forEach(o=>{o.value.specifiers=o.value.specifiers?.filter(n=>!e.ImportSpecifier.check(n)||n.imported.name!=="useSearchParams"),o.value.specifiers?.length===0&&(a=!0)}),a&&t.remove(),[!0,[]]},D=(e,t,a)=>{let o=[];return t.find(e.ImportDeclaration,{source:{value:"next/navigation"}}).forEach(n=>{o.push([w,e(n),a])}),[!1,o]};function v(e,t,a){let o=!1,n=e.withParser("tsx"),r=n(t),s=[[E,r,a]],i=l=>{let[c,h,p]=l,[f,m]=c(n,h,p);o||=f;for(let y of m)i(y)};for(let l of s)i(l);if(o)return i([D,r,a]),i([g,r,a]),r.toSource()}var z={kind:"noop"},b={includePatterns:["**/*.{jsx,tsx,js,ts,cjs,ejs}"],excludePatterns:["**/node_modules/**","**/pages/api/**"],initializeState:async(e,t)=>{let{useCompatSearchParamsHookAbsolutePath:a,useCompatSearchParamsHookRelativePath:o,useCompatSearchParamsHookModuleSpecifier:n}=e,r=typeof a=="string"&&a!=="",s=typeof o=="string"&&o!=="",i=r?"absolute":s?"relative":null,l=r?a:s?o:null;if(i===null||l===null||typeof n!="string")throw new Error("Neither the absolute nor the relative hook paths are present in the options");let c=typeof e.hookModuleCreation=="boolean"?e.hookModuleCreation:!0;return t??{hookModuleCreated:!1,hookPathType:i,hookPath:l,hookModuleSpecifier:n,hookModuleCreation:c}},handleFile:async(e,t,a,o)=>{let n=[];if(o!==null&&o.hookModuleCreation&&!o.hookModuleCreated)if(o.hookPathType==="relative"){let r=e.joinPaths(e.currentWorkingDirectory,o.hookPath);e.exists(r)||n.push({kind:"upsertFile",path:r,options:{...a,fileContent:u}}),o.hookModuleCreated=!0}else o.hookPathType==="absolute"&&(e.exists(o.hookPath)||n.push({kind:"upsertFile",path:o.hookPath,options:{...a,fileContent:u}}),o.hookModuleCreated=!0);return n.push({kind:"upsertFile",path:t,options:a}),n},handleData:async(e,t,a,o,n)=>{if(!n)throw new Error("Could not find state.");if("fileContent"in o&&typeof o.fileContent=="string")return{kind:"upsertData",path:t,data:o.fileContent};let{jscodeshift:r}=e.getDependencies(),s=v(r,a,n);return s===void 0?z:{kind:"upsertData",path:t,data:s}}};0&&(module.exports={USE_COMPAT_SEARCH_PARAMS_HOOK_CONTENT,repomod});
