/*! @license
*/
"use strict";var o=Object.defineProperty;var m=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var d=Object.prototype.hasOwnProperty;var v=(a,e)=>{for(var l in e)o(a,l,{get:e[l],enumerable:!0})},E=(a,e,l,t)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of c(e))!d.call(a,s)&&s!==l&&o(a,s,{get:()=>e[s],enumerable:!(t=m(e,s))||t.enumerable});return a};var y=a=>E(o({},"__esModule",{value:!0}),a);var x={};v(x,{default:()=>p});module.exports=y(x);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function k(a,e,l){let t=e.jscodeshift,s=t(a.source),u=!1;if(s.find(t.JSXElement,{openingElement:{name:{name:"Link"}}}).forEach(r=>{(r.value.openingElement.attributes??[]).filter(i=>"name"in i?i.name.name==="to":!1).forEach(i=>{("value"in i&&i.value&&"expression"in i.value&&"properties"in i.value.expression?i.value.expression.properties:[]).forEach(n=>{if("key"in n&&"name"in n.key&&n.key.name==="pathname"&&"value"in i&&"value"in n&&"value"in n.value&&n.value.value&&(i.value=t.literal(n.value.value),u=!0),"key"in n&&"name"in n.key&&n.key.name==="state"){let f=t.jsxAttribute(t.jsxIdentifier(n.key.name),t.jsxExpressionContainer(t.identifier("state")));r.value.openingElement.attributes?r.value.openingElement.attributes.push(f):r.value.openingElement.attributes=[f],u=!0}})})}),!!u)return s.toSource(l)}var p=k;
