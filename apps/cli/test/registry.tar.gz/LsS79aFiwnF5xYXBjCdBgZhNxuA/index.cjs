/*! @license
*/
"use strict";var s=Object.defineProperty;var a=Object.getOwnPropertyDescriptor;var u=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var d=(r,o)=>{for(var t in o)s(r,t,{get:o[t],enumerable:!0})},l=(r,o,t,n)=>{if(o&&typeof o=="object"||typeof o=="function")for(let e of u(o))!c.call(r,e)&&e!==t&&s(r,e,{get:()=>o[e],enumerable:!(n=a(o,e))||n.enumerable});return r};var m=r=>l(s({},"__esModule",{value:!0}),r);var v={};d(v,{default:()=>I});module.exports=m(v);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function p(r,o,t){let n=o.jscodeshift,e=n(r.source),f=!1;if(e.find(n.ImportDeclaration,{source:{value:"react-router-dom-v5-compat"}}).forEach(i=>{i.value.source.value="react-router-dom",f=!0}),!!f)return e.toSource(t)}var I=p;
