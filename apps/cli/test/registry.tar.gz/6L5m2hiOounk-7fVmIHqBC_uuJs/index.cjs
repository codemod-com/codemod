/*! @license
*/
"use strict";var a=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var u=Object.prototype.hasOwnProperty;var d=(n,e)=>{for(var o in e)a(n,o,{get:e[o],enumerable:!0})},p=(n,e,o,i)=>{if(e&&typeof e=="object"||typeof e=="function")for(let t of c(e))!u.call(n,t)&&t!==o&&a(n,t,{get:()=>e[t],enumerable:!(i=l(e,t))||i.enumerable});return n};var g=n=>p(a({},"__esModule",{value:!0}),n);var h={};d(h,{default:()=>I});module.exports=g(h);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function E(n,e,o){let i=e.jscodeshift,t=i(n.source),f=!1;if(t.find(i.JSXElement,{openingElement:{name:{name:"NavLink"}}}).forEach(m=>{let[r]=m.value.openingElement.attributes?.filter(s=>"name"in s?s.name.name==="exact":!1)??[];r&&"name"in r&&(r.name.name="end",f=!0)}),!!f)return t.toSource(o)}var I=E;
