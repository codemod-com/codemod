/*! @license
*/
"use strict";var l=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var g=(r,n)=>{for(var o in n)l(r,o,{get:n[o],enumerable:!0})},m=(r,n,o,t)=>{if(n&&typeof n=="object"||typeof n=="function")for(let a of c(n))!f.call(r,a)&&a!==o&&l(r,a,{get:()=>n[a],enumerable:!(t=u(n,a))||t.enumerable});return r};var d=r=>m(l({},"__esModule",{value:!0}),r);var v={};g(v,{default:()=>s});module.exports=d(v);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function s(r,n,o){let t=n.jscodeshift,a=t(r.source);return a.find(t.ImportDeclaration,{source:{value:"next/image"}}).forEach(e=>{e.node.source=t.stringLiteral("next/legacy/image")}),a.find(t.ImportExpression,{source:{value:"next/image"}}).forEach(e=>{e.node.source=t.stringLiteral("next/legacy/image")}),a.find(t.ImportDeclaration,{source:{value:"next/future/image"}}).forEach(e=>{e.node.source=t.stringLiteral("next/image")}),a.find(t.ImportExpression,{source:{value:"next/future/image"}}).forEach(e=>{e.node.source=t.stringLiteral("next/image")}),a.find(t.CallExpression).forEach(e=>{if(e?.value?.callee?.type==="Identifier"&&e.value.callee.name==="require"){let i=e.value.arguments[0];i&&i.type==="Literal"&&i.value==="next/image"&&(e.value.arguments[0]=t.literal("next/legacy/image"))}}),a.find(t.CallExpression).forEach(e=>{if(e?.value?.callee?.type==="Identifier"&&e.value.callee.name==="require"){let i=e.value.arguments[0];i&&i.type==="Literal"&&i.value==="next/future/image"&&(e.value.arguments[0]=t.literal("next/image"))}}),a.toSource(o)}
