# Remove Compat Router

## Description

