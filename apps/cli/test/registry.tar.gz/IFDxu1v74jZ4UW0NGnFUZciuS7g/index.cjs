/*! @license
*/
"use strict";var f=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var u=(t,e)=>{for(var o in e)f(t,o,{get:e[o],enumerable:!0})},l=(t,e,o,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let n of d(e))!p.call(t,n)&&n!==o&&f(t,n,{get:()=>e[n],enumerable:!(r=c(e,n))||r.enumerable});return t};var h=t=>l(f({},"__esModule",{value:!0}),t);var E={};u(E,{default:()=>I});module.exports=h(E);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function P(t,e,o){let r=e.jscodeshift,n=r(t.source),a=!1;if(n.find(r.ImportSpecifier,{imported:{name:"CompatRouter"}}).forEach(i=>{r(i.parentPath.parentPath).remove(),a=!0}),n.find(r.JSXElement,{openingElement:{name:{name:"CompatRouter"}}}).forEach(i=>{let s=i.value.children,m=i.parentPath.parentPath.node;r(i).remove(),m.children=s,a=!0}),!!a)return n.toSource(o)}var I=P;
