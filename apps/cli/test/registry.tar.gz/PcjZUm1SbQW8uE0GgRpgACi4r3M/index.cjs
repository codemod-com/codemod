/*! @license
*/
"use strict";var o=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var m=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var v=(t,e)=>{for(var n in e)o(t,n,{get:e[n],enumerable:!0})},g=(t,e,n,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of m(e))!p.call(t,s)&&s!==n&&o(t,s,{get:()=>e[s],enumerable:!(r=u(e,s))||r.enumerable});return t};var y=t=>g(o({},"__esModule",{value:!0}),t);var d={};v(d,{default:()=>f});module.exports=y(d);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function f(t,e){let n=e.jscodeshift,r=n(t.source);return r.find(n.CallExpression,{callee:{name:"useRouteMatch"}}).forEach(s=>{s.value.callee.name="useMatch",s.value.arguments.length>0&&s.value.arguments.filter(a=>a.type==="ObjectExpression").forEach(a=>{let[c]=a.properties.filter(i=>i.key.name==="strict");c&&(c.key.name="end");let[l]=a.properties.filter(i=>i.key.name==="sensitive");l&&(l.key.name="caseSensitive")})}),r.toSource()}
