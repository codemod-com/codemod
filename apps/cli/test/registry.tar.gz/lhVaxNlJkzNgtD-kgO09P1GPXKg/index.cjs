/*! @license
*/
"use strict";var d=Object.defineProperty;var I=Object.getOwnPropertyDescriptor;var b=Object.getOwnPropertyNames;var E=Object.prototype.hasOwnProperty;var J=(r,t)=>{for(var e in t)d(r,e,{get:t[e],enumerable:!0})},X=(r,t,e,s)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of b(t))!E.call(r,n)&&n!==e&&d(r,n,{get:()=>t[n],enumerable:!(s=I(t,n))||s.enumerable});return r};var j=r=>X(d({},"__esModule",{value:!0}),r);var x={};J(x,{default:()=>g});module.exports=j(x);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function g(r,t){let e=t.jscodeshift,s=e(r.source),n=!1;if(s.find(e.ImportDeclaration,{source:{value:"next/link"}}).forEach(m=>{if(e(m).find(e.ImportDefaultSpecifier).size()===0)return;let h=e(m).find(e.ImportDefaultSpecifier).find(e.Identifier).get("name").value;if(!h)return;let v=s.findJSXElements(h),y=s.findJSXElements("style").some(f=>e(f).find(e.JSXAttribute,{name:{name:"jsx"}}).size()!==0);v.forEach(f=>{let i=e(f).filter(a=>e(a).find(e.JSXAttribute,{name:{name:"legacyBehavior"}}).size()===0);if(i.size()===0)return;if(y){i.get("attributes").push(e.jsxAttribute(e.jsxIdentifier("legacyBehavior"))),n=!0;return}let l=i.get("children");if(l.value&&l.value.length===1&&l.value[0].type==="JSXText")return;let o=i.childElements().filter(a=>e(a).find(e.JSXOpeningElement).get("name").get("name").value==="a");if(o.size()!==1){i.get("attributes").push(e.jsxAttribute(e.jsxIdentifier("legacyBehavior"))),n=!0;return}let c=o.get("attributes").value;if(c.length>0){let a=i.get("attributes").value.map(u=>u?.name?.name),p=[];c.forEach(u=>{a.includes(u?.name?.name)||p.push(u)}),i.get("attributes").value.push(...p),n=!0,c.length=0}let S=o.get("children");o.replaceWith(S.value),n=!0})}),!!n)return s.toSource()}
