/*! @license
*/
"use strict";var f=Object.defineProperty;var y=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var H=(i,e)=>{for(var o in e)f(i,o,{get:e[o],enumerable:!0})},g=(i,e,o,t)=>{if(e&&typeof e=="object"||typeof e=="function")for(let r of d(e))!p.call(i,r)&&r!==o&&f(i,r,{get:()=>e[r],enumerable:!(t=y(e,r))||t.enumerable});return i};var v=i=>g(f({},"__esModule",{value:!0}),i);var b={};H(b,{default:()=>E});module.exports=v(b);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function I(i,e,o){let t=e.jscodeshift,r=t(i.source),s=!1;if(r.find(t.JSXElement,{openingElement:{name:{name:"Router"}}}).forEach(h=>{let a=h.value.openingElement.attributes;if(!a)return;if(a.filter(n=>"name"in n?n.name.name==="history":!1).length>0){let[n]=a.filter(c=>"name"in c?c.name.name==="history":!1);n&&"value"in n&&(n.value=t.jsxExpressionContainer(t.identifier("history")),s=!0)}if(r.find(t.ImportDeclaration,{source:{value:"history/createHashHistory"}}).length>0)return;let m=t.importDeclaration([t.importDefaultSpecifier(t.identifier("createHashHistory"))],t.literal("history/createHashHistory")),l=r.get().value.program.body;l.unshift(m);let u=t.variableDeclaration("const",[t.variableDeclarator(t.identifier("history"),t.callExpression(t.identifier("createHashHistory"),[]))]);l.unshift(u),s=!0}),!!s)return r.toSource(o)}var E=I;
