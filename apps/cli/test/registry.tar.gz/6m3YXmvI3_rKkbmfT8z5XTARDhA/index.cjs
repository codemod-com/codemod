/*! @license
*/
"use strict";var l=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var y=Object.getOwnPropertyNames;var A=Object.prototype.hasOwnProperty;var E=(n,r)=>{for(var a in r)l(n,a,{get:r[a],enumerable:!0})},j=(n,r,a,e)=>{if(r&&typeof r=="object"||typeof r=="function")for(let t of y(r))!A.call(n,t)&&t!==a&&l(n,t,{get:()=>r[t],enumerable:!(e=d(r,t))||e.enumerable});return n};var F=n=>j(l({},"__esModule",{value:!0}),n);var g={};E(g,{default:()=>S});module.exports=F(g);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function I(n,r,a){let e=r.jscodeshift,t=e(n.source),u=!1;if(t.findJSXElements("NavLink").forEach(f=>{let p=f.value.openingElement.attributes;if(!p)return;let[i]=p.filter(o=>"name"in o?o.name.name==="style":!1);if(!i||!("value"in i)||!i.value||!("expression"in i.value)||!i.value.expression||!("properties"in i.value.expression)||!i.value.expression.properties[0]||!("key"in i.value.expression.properties[0])||!("name"in i.value.expression.properties[0].key)||!("value"in i.value.expression.properties[0])||!("value"in i.value.expression.properties[0].value)||!i.value.expression.properties[0].value.value)return;let v=i.value.expression.properties[0].key.name;if(typeof v!="string")return;let[s]=p.filter(o=>"name"in o?o.name.name==="activeStyle":!1);if(!s||!("value"in s)||!s.value||!("expression"in s.value)||!("properties"in s.value.expression)||!s.value.expression.properties[0]||!("value"in s.value.expression.properties[0])||!("value"in s.value.expression.properties[0].value)||!s.value.expression.properties[0].value.value)return;let c=p.findIndex(o=>"name"in o?o.name.name==="activeStyle":!1);p.splice(c,1);let x=e.property("init",e.literal("isActive"),e.identifier("isActive")),m=e.objectExpression([e.property("init",e.literal(v),e.conditionalExpression(e.identifier("isActive"),e.literal(s.value.expression.properties[0].value.value),e.literal(i.value.expression.properties[0].value.value)))]);i.value=e.jsxExpressionContainer(e.arrowFunctionExpression([e.objectPattern([x])],m)),u=!0}),!!u)return t.toSource(a)}var S=I;
