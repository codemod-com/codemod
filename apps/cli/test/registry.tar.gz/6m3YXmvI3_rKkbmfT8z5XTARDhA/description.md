# Remove Active Style

## Description

