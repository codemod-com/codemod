/*! @license
*/
"use strict";var a=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var l=Object.prototype.hasOwnProperty;var m=(s,e)=>{for(var t in e)a(s,t,{get:e[t],enumerable:!0})},f=(s,e,t,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let r of p(e))!l.call(s,r)&&r!==t&&a(s,r,{get:()=>e[r],enumerable:!(n=h(e,r))||n.enumerable});return s};var u=s=>f(a({},"__esModule",{value:!0}),s);var x={};m(x,{default:()=>g});module.exports=u(x);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var i=class{j;path;argumentsMatch;constructor(e,t){this.j=e,this.path=t,this.argumentsMatch=this.checkArgumentContract()}checkArgumentContract(){let e=this.path.node;if(e.arguments.length!==2)return!1;let t=e.arguments[0];return!(t?.type!=="Literal"&&t?.type!=="Identifier")}transform(){if(!this.argumentsMatch)return;let e=this.path.node.arguments[0],t=e,n=!0;e?.type==="Literal"&&(t=this.j.identifier(`${e.value}`),n=!1);let r=this.path.node.callee,c=this.j.memberExpression(r.object,t,n),o=this.path.node.arguments[1];this.path.replace(this.j.assignmentExpression("=",c,o))}},d=(s,e,t)=>{let n=e.jscodeshift,r=n(s.source);return r.find(n.CallExpression,{callee:{type:"MemberExpression",property:{type:"Identifier",name:"set"}}}).forEach(o=>new i(n,o).transform()),r.toSource(t)},g=d;
