/*! @license
*/
"use strict";var s=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var l=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var h=(t,r)=>{for(var o in r)s(t,o,{get:r[o],enumerable:!0})},m=(t,r,o,e)=>{if(r&&typeof r=="object"||typeof r=="function")for(let i of l(r))!p.call(t,i)&&i!==o&&s(t,i,{get:()=>r[i],enumerable:!(e=u(r,i))||e.enumerable});return t};var g=t=>m(s({},"__esModule",{value:!0}),t);var j={};h(j,{default:()=>D});module.exports=g(j);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function y(t,r,o){let e=r.jscodeshift,i=e(t.source),f=!1;if(i.find(e.CallExpression,{callee:{name:"createGraphQLHandler"}}).forEach(d=>{let n=d.value.arguments[0];if(!n||!("properties"in n)||n.properties.filter(a=>"key"in a&&"name"in a.key?a.key.name==="authDecoder":!1).length)return;f=!0,n.properties.unshift(e.objectProperty(e.identifier("authDecoder"),e.identifier("authDecoder")));let c=e.importDeclaration([e.importSpecifier(e.identifier("authDecoder"),e.identifier("authDecoder"))],e.stringLiteral("@redwoodjs/auth-auth0-api"));i.get().value.program.body.unshift(c)}),!!f)return i.toSource(o)}var D=y;
