/*! @license
*/
"use strict";var r=Object.defineProperty;var i=Object.getOwnPropertyDescriptor;var u=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var l=(t,e)=>{for(var m in e)r(t,m,{get:e[m],enumerable:!0})},d=(t,e,m,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of u(e))!f.call(t,s)&&s!==m&&r(t,s,{get:()=>e[s],enumerable:!(o=i(e,s))||o.enumerable});return t};var p=t=>d(r({},"__esModule",{value:!0}),t);var I={};l(I,{default:()=>b});module.exports=p(I);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Changes to the original file: added options
*/var h=(t,e,m)=>{let o=e.jscodeshift,s=o(t.source),n=s.find(o.ImportDeclaration,{source:{value:"immutable"}});if(n.length>0){let c=[o.commentLine(" ImmutableJS usage is deprecated",!0,!1),o.commentLine(" Please, do not copy & paste or use this snippet as reference :)",!0,!1),o.commentLine(" How to refactor? See https://github.com/quintoandar/farewell-immutablejs/blob/master/MIGRATION.md",!0,!1)];n.at(0).forEach(a=>{(a.node.comments=a.node.comments||[]).push(...c)})}return s.toSource(m)},b=h;
