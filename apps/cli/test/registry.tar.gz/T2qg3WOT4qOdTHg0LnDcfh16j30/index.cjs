/*! @license
*/
"use strict";var n=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var m=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var g=(t,e)=>{for(var r in e)n(t,r,{get:e[r],enumerable:!0})},x=(t,e,r,a)=>{if(e&&typeof e=="object"||typeof e=="function")for(let l of m(e))!f.call(t,l)&&l!==r&&n(t,l,{get:()=>e[l],enumerable:!(a=u(e,l))||a.enumerable});return t};var d=t=>x(n({},"__esModule",{value:!0}),t);var j={};g(j,{default:()=>o});module.exports=d(j);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/cp-property-map/index.js
 
MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function o(t,e){let r=e.jscodeshift,a=r(t.source);return a.find(r.CallExpression,{callee:{type:"MemberExpression",object:{callee:{name:"map"}},property:{name:"property"}}}).replaceWith(l=>{let s=l.value.callee.object.arguments,c=s.slice(0,s.length-1),i=s[s.length-1],p=[].concat(c,r.arrayExpression(l.value.arguments),i);return r.callExpression(r.identifier("map"),p)}),a.toSource()}
