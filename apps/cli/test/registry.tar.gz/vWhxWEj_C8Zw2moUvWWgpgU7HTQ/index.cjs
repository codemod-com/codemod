/*! @license
*/
"use strict";var i=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var c=Object.prototype.hasOwnProperty;var l=(r,e)=>{for(var t in e)i(r,t,{get:e[t],enumerable:!0})},m=(r,e,t,s)=>{if(e&&typeof e=="object"||typeof e=="function")for(let n of h(e))!c.call(r,n)&&n!==t&&i(r,n,{get:()=>e[n],enumerable:!(s=p(e,n))||s.enumerable});return r};var u=r=>m(i({},"__esModule",{value:!0}),r);var d={};l(d,{default:()=>E});module.exports=u(d);/*! @license

MIT License

Copyright (c) 2020 QuintoAndar.com.br

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var o=class{j;path;argumentsMatch;constructor(e,t){this.j=e,this.path=t,this.argumentsMatch=this.checkArgumentContract()}checkArgumentContract(){let e=this.path.node;return e.arguments.length!==2?!1:e.arguments[0]?.type==="ArrayExpression"}transform(){if(!this.argumentsMatch)return;let e=this.path.node.arguments[0],t=this.path.node.arguments[1];this.path.replace(this.j.assignmentExpression("=",this.generate(e),t))}generate(e,t=e.elements.length-1){if(t===-1)return this.path.node.callee.object;{let s=e.elements[t];return this.j.memberExpression(this.generate(e,t-1),this.normalizeProperty(s),this.isComputed(s))}}normalizeProperty(e){return e?.type==="Literal"?this.j.identifier(`${e.value}`):e}isComputed(e){return e?.type!=="Literal"}},f=(r,e,t)=>{let s=e.jscodeshift,n=s(r.source);return n.find(s.CallExpression,{callee:{type:"MemberExpression",property:{type:"Identifier",name:"setIn"}}}).forEach(a=>new o(s,a).transform()),n.toSource(t)},E=f;
