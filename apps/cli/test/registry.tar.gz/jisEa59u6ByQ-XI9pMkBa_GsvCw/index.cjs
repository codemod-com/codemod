/*! @license
*/
"use strict";var p=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var m=Object.getOwnPropertyNames;var s=Object.prototype.hasOwnProperty;var u=(o,t)=>{for(var e in t)p(o,e,{get:t[e],enumerable:!0})},d=(o,t,e,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of m(t))!s.call(o,r)&&r!==e&&p(o,r,{get:()=>t[r],enumerable:!(i=l(t,r))||i.enumerable});return o};var f=o=>d(p({},"__esModule",{value:!0}),o);var b={};u(b,{default:()=>n});module.exports=f(b);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/fpe-computed/index.js

MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function n(o,t){let e=t.jscodeshift,i=e(o.source),r=!1;return i.find(e.ImportDeclaration,{source:{value:"@ember/object"}}).find(e.ImportSpecifier,{imported:{name:"computed"}}).size()&&(r=!0),i.find(e.CallExpression,{callee:{type:"MemberExpression",object:{type:"FunctionExpression"},property:{name:"property"}}}).replaceWith(c=>{let a=e.importDeclaration([e.importSpecifier(e.identifier("computed"))],e.literal("@ember/object"));return r||(i.get().value.program.body.unshift(a),r=!0),e.callExpression(e.identifier("computed"),c.value.arguments.concat(c.value.callee.object))}),i.toSource({quote:"single"})}
