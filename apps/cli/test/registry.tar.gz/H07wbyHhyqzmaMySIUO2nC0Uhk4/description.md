# Generate URL Patterns for Cal.com

## Description

This codemod generates URL Patterns for all existing paths under the apps router to be placed in the middleware file that controls which pages are active.