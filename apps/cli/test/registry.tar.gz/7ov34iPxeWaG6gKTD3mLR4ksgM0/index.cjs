/*! @license
*/
"use strict";var n=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var m=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var s=(t,r)=>{for(var e in r)n(t,e,{get:r[e],enumerable:!0})},u=(t,r,e,i)=>{if(r&&typeof r=="object"||typeof r=="function")for(let o of m(r))!p.call(t,o)&&o!==e&&n(t,o,{get:()=>r[o],enumerable:!(i=c(r,o))||i.enumerable});return t};var d=t=>u(n({},"__esModule",{value:!0}),t);var f={};s(f,{default:()=>a});module.exports=d(f);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/ember-jquery-legacy/index.js

MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function a(t,r){let e=r.jscodeshift,i=e(t.source);return i.find(e.MemberExpression,{object:{name:"event"},property:{name:"originalEvent"}}).replaceWith(o=>{let l=e.importDeclaration([e.importSpecifier(e.identifier("normalizeEvent"))],e.literal("ember-jquery-legacy"));return i.get().value.program.body.unshift(l),e.callExpression(e.identifier("normalizeEvent"),[o.value.object])}),i.toSource()}
