/*! @license
*/
"use strict";var a=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var u=Object.prototype.hasOwnProperty;var d=(r,o)=>{for(var n in o)a(r,n,{get:o[n],enumerable:!0})},p=(r,o,n,t)=>{if(o&&typeof o=="object"||typeof o=="function")for(let e of c(o))!u.call(r,e)&&e!==n&&a(r,e,{get:()=>o[e],enumerable:!(t=l(o,e))||t.enumerable});return r};var g=r=>p(a({},"__esModule",{value:!0}),r);var m={};d(m,{default:()=>f});module.exports=g(m);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Changes to the original file: simplify replaceWith statements, add dirtyFlag mechanics
*/function f(r,o,n){let t=o.jscodeshift.withParser("tsx"),e=t(r.source),i=!1;return e.find(t.ImportDeclaration,{source:{value:"@next/font"}}).forEach(s=>{i=!0,s.node.source=t.stringLiteral("next/font")}),e.find(t.ImportDeclaration,{source:{value:"@next/font/google"}}).forEach(s=>{i=!0,s.node.source=t.stringLiteral("next/font/google")}),e.find(t.ImportDeclaration,{source:{value:"@next/font/local"}}).replaceWith(s=>{i=!0,s.node.source=t.stringLiteral("next/font/local")}),i?e.toSource(n):void 0}
