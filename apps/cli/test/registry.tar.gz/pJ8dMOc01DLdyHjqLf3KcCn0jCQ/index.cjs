/*! @license
*/
"use strict";var s=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var u=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var p=(r,e)=>{for(var n in e)s(r,n,{get:e[n],enumerable:!0})},d=(r,e,n,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let t of u(e))!f.call(r,t)&&t!==n&&s(r,t,{get:()=>e[t],enumerable:!(o=l(e,t))||o.enumerable});return r};var m=r=>d(s({},"__esModule",{value:!0}),r);var x={};p(x,{default:()=>a});module.exports=m(x);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added options
*/function a(r,e,n){let o=e.jscodeshift,t=o(r.source);return t.find(o.CallExpression,{callee:{object:{name:"Seq"},property:{name:"of"}}}).replaceWith(c=>{let i=c.value.arguments;return o.callExpression(o.identifier("Seq"),[o.arrayExpression(i)])}),t.toSource(n)}
