/*! @license
*/
"use strict";var l=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var d=Object.prototype.hasOwnProperty;var p=(a,n)=>{for(var t in n)l(a,t,{get:n[t],enumerable:!0})},m=(a,n,t,i)=>{if(n&&typeof n=="object"||typeof n=="function")for(let r of c(n))!d.call(a,r)&&r!==t&&l(a,r,{get:()=>n[r],enumerable:!(i=u(n,r))||i.enumerable});return a};var v=a=>m(l({},"__esModule",{value:!0}),a);var E={};p(E,{default:()=>g});module.exports=v(E);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function x(a,n,t){let i=n.jscodeshift,r=i(a.source),s=!1;if(r.find(i.ImportDeclaration).filter(e=>e.value.specifiers?.some(o=>"imported"in o?o.imported.name==="useHistory":!1)??!1).forEach(e=>{let[o]=e.value.specifiers?.filter(f=>"imported"in f?f.imported.name==="useHistory":!1)??[];o&&"imported"in o&&(o.imported.name="useNavigate",s=!0)}),r.find(i.VariableDeclarator,{init:{callee:{name:"useHistory"}}}).forEach(e=>{if(e.value.init&&"callee"in e.value.init&&"name"in e.value.init.callee&&(e.value.init.callee.name="useNavigate",s=!0),"properties"in e.value.id){let o=i.objectProperty(i.identifier("navigate"),i.identifier("navigate"));e.value.id.properties=[o],s=!0}}),r.find(i.CallExpression,{callee:{name:"go"}}).forEach(e=>{"name"in e.value.callee&&(e.value.callee.name="navigate",s=!0)}),r.find(i.JSXExpressionContainer).filter(e=>"name"in e.value.expression?e.value.expression.name==="goBack":!1).forEach(e=>{e.value.expression=i.arrowFunctionExpression([],i.callExpression(i.identifier("navigate"),[i.literal(-1)])),s=!0}),r.find(i.JSXExpressionContainer).filter(e=>"name"in e.value.expression?e.value.expression.name==="goForward":!1).forEach(e=>{e.value.expression=i.arrowFunctionExpression([],i.callExpression(i.identifier("navigate"),[i.literal(1)])),s=!0}),!!s)return r.toSource(t)}var g=x;
