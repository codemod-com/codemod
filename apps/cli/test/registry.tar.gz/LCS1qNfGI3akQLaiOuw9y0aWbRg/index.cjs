/*! @license
*/
"use strict";var n=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var d=Object.prototype.hasOwnProperty;var l=(r,e)=>{for(var o in e)n(r,o,{get:e[o],enumerable:!0})},m=(r,e,o,i)=>{if(e&&typeof e=="object"||typeof e=="function")for(let t of c(e))!d.call(r,t)&&t!==o&&n(r,t,{get:()=>e[t],enumerable:!(i=u(e,t))||i.enumerable});return r};var p=r=>m(n({},"__esModule",{value:!0}),r);var v={};l(v,{default:()=>h});module.exports=p(v);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function I(r,e,o){let i=e.jscodeshift,t=i(r.source),a=!1;if(t.find(i.ImportDeclaration,{}).forEach(s=>{(s.value.specifiers?.filter(f=>"imported"in f?f.imported.name==="StaticRouter":!1).length??0>0)&&(s.value.source.value="react-router-dom/server")}),!!a)return t.toSource(o)}var h=I;
