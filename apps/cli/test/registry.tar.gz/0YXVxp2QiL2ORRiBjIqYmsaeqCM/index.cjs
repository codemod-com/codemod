/*! @license
*/
"use strict";var o=Object.defineProperty;var m=Object.getOwnPropertyDescriptor;var c=Object.getOwnPropertyNames;var d=Object.prototype.hasOwnProperty;var h=(n,e)=>{for(var i in e)o(n,i,{get:e[i],enumerable:!0})},p=(n,e,i,t)=>{if(e&&typeof e=="object"||typeof e=="function")for(let r of c(e))!d.call(n,r)&&r!==i&&o(n,r,{get:()=>e[r],enumerable:!(t=m(e,r))||t.enumerable});return n};var A=n=>p(o({},"__esModule",{value:!0}),n);var b={};h(b,{default:()=>j});module.exports=A(b);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function g(n,e,i){let t=e.jscodeshift,r=t(n.source),u=!1;if(r.find(t.JSXElement,{openingElement:{name:{name:"Router"}}}).forEach(a=>{let s=a.value.openingElement.attributes;if(!s||s.filter(f=>"name"in f?f.name.name==="useAuth":!1).length)return;s.push(t.jsxAttribute(t.jsxIdentifier("useAuth"),t.jsxExpressionContainer(t.identifier("useAuth"))));let l=t.importDeclaration([t.importSpecifier(t.identifier("useAuth"),t.identifier("useAuth"))],t.stringLiteral("src/auth"));r.get().value.program.body.unshift(l),u=!0}),!!u)return r.toSource(i)}var j=g;
