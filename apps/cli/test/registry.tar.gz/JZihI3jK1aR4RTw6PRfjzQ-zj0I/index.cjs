/*! @license
*/
"use strict";var u=Object.defineProperty;var v=Object.getOwnPropertyDescriptor;var S=Object.getOwnPropertyNames;var N=Object.prototype.hasOwnProperty;var P=(r,e)=>{for(var t in e)u(r,t,{get:e[t],enumerable:!0})},O=(r,e,t,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let i of S(e))!N.call(r,i)&&i!==t&&u(r,i,{get:()=>e[i],enumerable:!(o=v(e,i))||o.enumerable});return r};var w=r=>O(u({},"__esModule",{value:!0}),r);var q={};P(q,{default:()=>T});module.exports=w(q);var f=require("path");/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var y=(r,e,t)=>{r.find(e.CallExpression,{callee:{type:"MemberExpression",object:{type:"Identifier",name:"jest"},property:{type:"Identifier"}}}).filter(o=>{let{callee:i}=o.value;return!e.MemberExpression.check(i)||!e.Identifier.check(i.property)?!1:["mock","setMock"].includes(i.property.name)}).forEach(o=>{let{arguments:i}=o.value;if(i.length<2)return;let[s,n]=i;if(n.type!=="ArrowFunctionExpression"&&n.type!=="FunctionExpression"||s.type!=="Literal"&&s.type!=="StringLiteral")return;let p=(0,f.resolve)((0,f.join)((0,f.dirname)(t),s.value));if(typeof require(p)=="object")return;if(n.type==="ArrowFunctionExpression"){let a=n.body;if(a.type==="ObjectExpression"&&a.properties.map(m=>{if(!(!e.ObjectProperty.check(m)||!e.Identifier.check(m.key)))return m.key.name}).filter(Boolean).includes("default"))return;if(a.type!=="BlockStatement"){n.body=e.objectExpression([e.property("init",e.identifier("default"),a)]);return}}if(!e.FunctionExpression.check(n)&&!e.ArrowFunctionExpression.check(n))return;let c=n.body;if(!e.BlockStatement.check(c))return;let d=c.body[c.body.length-1];if(d.type==="ReturnStatement"){let a=d.argument;if(a){if(a.type==="ObjectExpression"&&a.properties.map(m=>{if(!(!e.ObjectProperty.check(m)||!e.Identifier.check(m.key)))return m.key.name}).filter(Boolean).includes("default"))return;d.argument=e.objectExpression([e.property("init",e.identifier("default"),a)])}}})};/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var h=(r,e)=>{r.find(e.CallExpression,{callee:{object:{type:"Identifier",name:"jest"},property:{type:"Identifier",name:"setMock"}}}).forEach(t=>{let{arguments:o}=t.value;if(o.length<2)return;let i=o[1];i.type==="ObjectExpression"&&(o[1]=e.arrowFunctionExpression([],i))})};/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var B=["afterAll","afterEach","beforeAll","beforeEach","describe","test","it","fit","expect"],b=["concurrent","each","only","skip","todo","failing"],J={describe:["each","only","skip"],fit:["each","failing"],it:b,test:b},k={fit:"it",jest:"vi"},x=(r,e)=>{let t=[];for(let[s,n]of Object.entries(J)){let p=r.find(e.MemberExpression,{object:{name:s},property:{type:"Identifier"}}).nodes().map(c=>e.Identifier.check(c.property)&&c.property.name).filter(Boolean),l=[...new Set(p)];for(let c of l)if(n.includes(c)){t.push(k[s]??s);break}}let o="jest";return r.find(e.MemberExpression,{object:{name:o},property:{type:"Identifier"}}).filter(s=>e.Identifier.check(s.node.property)&&s.node.property.name!=="disableAutomock").length&&t.push(k[o]??o),t},g=(r,e)=>{let t=[];for(let o of B)r.find(e.CallExpression,{callee:{name:o}}).length>0&&t.push(o!=="fit"?o:"it");return t};/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var E=(r,e,t)=>{let o=r.find(e.ImportDeclaration);if(o.length>0){let n=o.at(0),p=n.nodes()[0];p?.comments&&(t.comments=p.comments,p.comments=null),n.insertBefore(t);return}let i=r.find(e.Program).get("body",0).node,{comments:s}=i;if(s?.length){let n=s[0];(n.type==="Block"||n.type==="CommentBlock")&&!n.value.startsWith("*")&&(t.comments=s,i.comments=null)}r.get("program","body").unshift(t)};/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var A={createMockFromModule:"importMock",deepUnmock:"unmock",genMockFromModule:"importMock",requireActual:"importActual",requireMock:"importMock",setMock:"mock"},D=["genMockFromModule","createMockFromModule","requireActual","requireMock"],I=(r,e)=>{r.find(e.MemberExpression,{object:{type:"Identifier",name:"jest"}}).forEach(t=>{if(!e.Identifier.check(t.node.property))return;let o=t.node.property.name;if(o==="enableAutomock")throw new Error(`The automocking API "${o}" is not supported in vitest.
See https://vitest.dev/guide/migration.html`);if(o==="disableAutomock"){e(t.parentPath).remove();return}if(A[o]&&(t.node.property.name=A[o]),D.includes(o)){e(t.parentPath).replaceWith(s=>e.awaitExpression(s.value));let i=t.parentPath;for(;!["FunctionExpression","ArrowFunctionExpression"].includes(i.value.type);)i=i.parentPath;i.value.async=!0}t.node.object=e.identifier("vi")})};/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/var M="failing",C="fails",F=(r,e)=>{for(let t of["it","test"]){r.find(e.MemberExpression,{object:{type:"Identifier",name:t},property:{type:"Identifier",name:M}}).forEach(o=>{o.node.property.name=C});for(let o of["only","skip"])r.find(e.MemberExpression,{object:{object:{type:"Identifier",name:t},property:{type:"Identifier",name:o}},property:{type:"Identifier",name:M}}).forEach(i=>{i.node.property.name=C})}},j=(r,e)=>{let t="fit",o=e.memberExpression(e.identifier("it"),e.identifier("only"));r.find(e.CallExpression,{callee:{type:"Identifier",name:t}}).forEach(i=>{i.node.callee=o});for(let i of["each","failing"])r.find(e.MemberExpression,{object:{type:"Identifier",name:t},property:{type:"Identifier",name:i}}).forEach(s=>{s.node.object=o})};/*! @license
MIT License

Copyright (c) 2023 Trivikram Kamat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function T(r,e){if(r.path.endsWith(".snap"))return r.source.replace("Array [","[").replace("Object {","{");let t=e.jscodeshift,o=t(r.source),i=g(o,t),s=x(o,t),n=[...new Set([...i,...s])];if(n.length){n.sort();let p=n.map(c=>t.importSpecifier(t.identifier(c))),l=t.importDeclaration(p,t.stringLiteral("vitest"));E(o,t,l)}return j(o,t),F(o,t),h(o,t),y(o,t,r.path),I(o,t),o.find(t.ImportDeclaration,{source:{value:"@jest/globals"}}).remove(),o.toSource()}
