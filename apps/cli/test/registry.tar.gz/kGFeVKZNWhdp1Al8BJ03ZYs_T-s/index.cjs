/*! @license
*/
"use strict";var T=Object.create;var d=Object.defineProperty;var k=Object.getOwnPropertyDescriptor;var O=Object.getOwnPropertyNames;var w=Object.getPrototypeOf,J=Object.prototype.hasOwnProperty;var P=(e,t)=>{for(var i in t)d(e,i,{get:t[i],enumerable:!0})},S=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of O(t))!J.call(e,r)&&r!==i&&d(e,r,{get:()=>t[r],enumerable:!(n=k(t,r))||n.enumerable});return e};var b=(e,t,i)=>(i=e!=null?T(w(e)):{},S(t||!e||!e.__esModule?d(i,"default",{value:e,enumerable:!0}):i,e)),V=e=>S(d({},"__esModule",{value:!0}),e);var X={};P(X,{default:()=>W});module.exports=V(X);/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/ast.js

Changes: move the code from JavaScript to TypeScript
*/var m=(e,t,i,n=[])=>{let r=e.find(t.VariableDeclarator,{init:{type:"Identifier",name:i}});return r.length>0&&r.forEach(u=>{n.push(u.node.id.name),m(e,t,u.node.id.name,n)}),n};/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/config.js

*/var E={quote:"single"};var x=b(require("os"),1),D=b(require("path"),1);/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/marker.js

Changes to the original file: 
1. changed imports to esm 
2. removed getDependencies
*/var $=D.default.join(process.env.NODE_ENV==="local"?process.cwd():x.default.tmpdir(),"./antd5-codemod-marker.log");/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/index.js
*/function A(e){return(e||"").split(",").filter(t=>t).map(t=>t.trim())}/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/v5-removed-static-method-migration.js
Changes to the original file: changed imports to esm 
*/var h={message:{hook:"useMessage",replace:{warn:"warning"}},notification:{hook:"useNotification",replace:{close:"destroy"}}},N=(e,t,i)=>{let n=t.jscodeshift,r=n(e.source),u=A(i.antdPkgNames||"antd");function y(c,f){let o=h[f]?.replace;o&&Object.entries(o).forEach(([a,s])=>{r.find(n.CallExpression,{callee:{type:"MemberExpression",object:{type:"Identifier",name:c},property:{type:"Identifier",name:a}}}).forEach(p=>{p.node.callee.property.name=s})})}function C(c,f){let o=h[f]?.replace;o&&Object.entries(o).forEach(([,a])=>{r.find(n.CallExpression,{callee:{type:"MemberExpression",object:{type:"MemberExpression",object:{type:"Identifier",name:c},property:{type:"NumericLiteral",value:0}}}}).forEach(s=>{s.node.callee.property.name=a})})}function g(c,f){if(c.node.id.type==="ArrayPattern"){let o=c.node.id.elements[0].name;m(r,n,o,[o]).forEach(s=>{y(s,f),l=!0})}else if(c.node.id.type==="Identifier"){let o=c.node.id.name;m(r,n,o,[o]).forEach(s=>{r.find(n.VariableDeclarator,{init:{type:"Identifier",name:s}}).forEach(p=>{g(p,f),l=!0}),C(s,f)})}}function v(c,f){let o=!1;return f.find(c.Identifier).filter(a=>Object.keys(h).includes(a.node.name)&&a.parent.node.type==="ImportSpecifier"&&u.includes(a.parent.parent.node.source.value)).forEach(a=>{let s=a.parent.node.imported.name,p=a.parent.node.local.name;y(p,s),o=!0;let I=h[s]?.hook;I&&f.find(c.VariableDeclarator,{init:{type:"CallExpression",callee:{type:"MemberExpression",property:{type:"Identifier",name:I}}}}).forEach(M=>{g(M,s)})}),o}let l=!1;return l=v(n,r)||l,l?r.toSource(i.printOptions||E):null},W=N;
