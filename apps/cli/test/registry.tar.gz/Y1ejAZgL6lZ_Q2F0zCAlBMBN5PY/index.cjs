/*! @license
*/
"use strict";var n=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var s=Object.getOwnPropertyNames;var u=Object.prototype.hasOwnProperty;var m=(r,t)=>{for(var a in t)n(r,a,{get:t[a],enumerable:!0})},d=(r,t,a,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let e of s(t))!u.call(r,e)&&e!==a&&n(r,e,{get:()=>t[e],enumerable:!(o=p(t,e))||o.enumerable});return r};var f=r=>d(n({},"__esModule",{value:!0}),r);var b={};m(b,{default:()=>l});module.exports=f(b);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added the options parameter 
*/function l(r,t,a){let o=t.jscodeshift,e=o(r.source);if(!e.find(o.ImportDeclaration,{source:{value:"react-router-dom-v5-compat"}}).length){let i=o.importDeclaration([o.importSpecifier(o.identifier("useLocation"))],o.literal("react-router-dom-v5-compat"));e.get().value.program.body.unshift(i)}return e.find(o.VariableDeclarator,{init:{object:{name:"props"},property:{name:"location"}}}).forEach(i=>{let c=o.variableDeclaration("const",[o.variableDeclarator(o.identifier("location"),o.callExpression(o.identifier("useLocation"),[]))]);i.parent.replace(c)}),e.toSource(a)}
