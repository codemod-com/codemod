/*! @license
*/
"use strict";var h=Object.defineProperty;var E=Object.getOwnPropertyDescriptor;var I=Object.getOwnPropertyNames;var P=Object.prototype.hasOwnProperty;var w=(e,a)=>{for(var u in a)h(e,u,{get:a[u],enumerable:!0})},z=(e,a,u,p)=>{if(a&&typeof a=="object"||typeof a=="function")for(let m of I(a))!P.call(e,m)&&m!==u&&h(e,m,{get:()=>a[m],enumerable:!(p=E(a,m))||p.enumerable});return e};var A=e=>z(h({},"__esModule",{value:!0}),e);var O={};w(O,{default:()=>S});module.exports=A(O);var g=require("fs"),x=require("path");/*! @license

The MIT License (MIT)

Copyright (c) 2023 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function v(e,a,u){let p={intrinsic:{maxWidth:"100%",height:"auto"},responsive:{width:"100%",height:"auto"},fill:null,fixed:null},m={intrinsic:null,responsive:"100vw",fill:"100vw",fixed:null};a.find(e.JSXElement).filter(i=>i.value.openingElement.name&&i.value.openingElement.name.type==="JSXIdentifier"&&i.value.openingElement.name.name===u).forEach(i=>{let l="intrinsic",n=null,s=null,o=[],c=null,d=i.node.openingElement.attributes?.filter(t=>t.type!=="JSXAttribute"?!0:t.name.name==="layout"&&t.value&&"value"in t.value?(l=String(t.value.value),!1):t.name.name==="objectFit"&&t.value&&"value"in t.value?(n=String(t.value.value),!1):t.name.name==="objectPosition"&&t.value&&"value"in t.value?(s=String(t.value.value),!1):t.name.name==="lazyBoundary"||t.name.name==="lazyRoot"?!1:t.name.name==="style"?(t.value?.type==="JSXExpressionContainer"&&t.value.expression.type==="ObjectExpression"?o=t.value.expression.properties:t.value?.type==="JSXExpressionContainer"&&t.value.expression.type==="Identifier"?o=[e.spreadElement(e.identifier(t.value.expression.name))]:console.warn("Unknown style attribute value detected",t.value),!1):t.name.name==="sizes"?(c=t,!1):!(t.name.name==="lazyBoundary"||t.name.name==="lazyRoot"));l==="fill"&&d?.push(e.jsxAttribute(e.jsxIdentifier("fill")));let r=m[l];r&&!c&&(c=e.jsxAttribute(e.jsxIdentifier("sizes"),e.literal(r))),c&&d?.push(c);let f=p[l];if(f||n||s){f||(f={}),n&&(f.objectFit=n),s&&(f.objectPosition=s),Object.entries(f).forEach(([y,b])=>{o.push(e.objectProperty(e.identifier(y),e.stringLiteral(b)))});let t=e.jsxAttribute(e.jsxIdentifier("style"),e.jsxExpressionContainer(e.objectExpression(o)));d?.push(t)}e(i).replaceWith(e.jsxElement(e.jsxOpeningElement(i.node.openingElement.name,d,i.node.openingElement.selfClosing),i.node.closingElement,i.node.children))})}function C(e,a,u){return a.find(e.ObjectExpression).forEach(p=>{let m=["imgix","cloudinary","akamai"],i=e(p).find(e.ObjectProperty,{key:{type:"Identifier",name:"images"}}),l=i.map(r=>e(r).find(e.ObjectProperty,{key:{type:"Identifier",name:"loader"}}).paths()).map(r=>e(r).find(e.StringLiteral).paths()).filter((r,f)=>f===0&&m.includes(r.value.value)),n=i.map(r=>e(r).find(e.ObjectProperty,{key:{type:"Identifier",name:"path"}}).paths()),s=l.nodes()[0]?.value,o=n.map(r=>e(r).find(e.StringLiteral).paths()).filter((r,f)=>f===0).nodes()[0]?.value;if(!s||!o)return;let c=`./${s}-loader.js`;l.replaceWith(()=>e.stringLiteral("custom")),n.remove(),e(p).find(e.ObjectProperty,{key:{type:"Identifier",name:"images"}}).forEach(r=>{e(r).find(e.ObjectExpression).filter((f,t)=>t===0).replaceWith(f=>{let t=f.value,y=[...t.properties,e.property("init",e.identifier("loaderFile"),e.literal(c))];return{...t,properties:y}})});let d="const normalizeSrc = (src) => src[0] === '/' ? src.slice(1) : src";s==="imgix"&&!u?(0,g.writeFileSync)(c,`${d}
		export default function imgixLoader({ src, width, quality }) {
			const url = new URL('${o}' + normalizeSrc(src))
			const params = url.searchParams
			params.set('auto', params.getAll('auto').join(',') || 'format')
			params.set('fit', params.get('fit') || 'max')
			params.set('w', params.get('w') || width.toString())
			if (quality) { params.set('q', quality.toString()) }
			return url.href
		}`.split(`
`).map(r=>r.trim()).join(`
`)):s==="cloudinary"&&!u?(0,g.writeFileSync)(c,`${d}
		export default function cloudinaryLoader({ src, width, quality }) {
			const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')]
			const paramsString = params.join(',') + '/'
			return '${o}' + paramsString + normalizeSrc(src)
		}`.split(`
`).map(r=>r.trim()).join(`
`)):s==="akamai"&&!u&&(0,g.writeFileSync)(c,`${d}
		export default function akamaiLoader({ src, width, quality }) {
			return '${o}' + normalizeSrc(src) + '?imwidth=' + width
		}`.split(`
`).map(r=>r.trim()).join(`
`))}),a}function S(e,a,u){if((0,x.basename)(e.path).startsWith("next.config.")){let n=a.jscodeshift.withParser("tsx"),s=n(e.source);return C(n,s,!!u.dryRun).toSource()}let i=a.jscodeshift,l=i(e.source);return l.find(i.ImportDeclaration,{source:{value:"next/legacy/image"}}).forEach(n=>{let o=n.node.specifiers?.find(c=>c.type==="ImportDefaultSpecifier")?.local?.name;o&&(n.node.source=i.stringLiteral("next/image"),v(i,l,o))}),l.find(i.ImportExpression,{source:{value:"next/legacy/image"}}).forEach(n=>{n.node.source=i.stringLiteral("next/image")}),l.find(i.CallExpression).forEach(n=>{if(n?.value?.callee?.type==="Identifier"&&n.value.callee.name==="require"){let s=n.value.arguments[0];if(s&&s.type==="Literal"&&s.value==="next/legacy/image"){let o=n?.parentPath?.value?.id?.name;o&&(n.value.arguments[0]=i.literal("next/image"),v(i,l,o))}}}),l.toSource(u)}
