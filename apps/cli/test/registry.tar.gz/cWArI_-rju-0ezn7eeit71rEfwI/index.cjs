/*! @license
*/
"use strict";var i=Object.defineProperty;var s=Object.getOwnPropertyDescriptor;var a=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var u=(t,o)=>{for(var e in o)i(t,e,{get:o[e],enumerable:!0})},d=(t,o,e,n)=>{if(o&&typeof o=="object"||typeof o=="function")for(let r of a(o))!p.call(t,r)&&r!==e&&i(t,r,{get:()=>o[r],enumerable:!(n=s(o,r))||n.enumerable});return t};var f=t=>d(i({},"__esModule",{value:!0}),t);var m={};u(m,{default:()=>l});module.exports=f(m);/*! @license
This code is based on a public codemod, which is subject to the original license terms.
Original codemod: https://github.com/ember-codemods/ember-3x-codemods/blob/master/transforms/fpe-on/index.js
 
MIT License

Copyright (c) 2019 ember-codemods

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

License URL: https://github.com/ember-codemods/ember-no-implicit-this-codemod/blob/master/LICENSE
 */function l(t,o){let e=o.jscodeshift,n=e(t.source);return n.find(e.CallExpression,{callee:{type:"MemberExpression",object:{type:"FunctionExpression"},property:{name:"on"}}}).replaceWith(r=>{let c=e.importDeclaration([e.importSpecifier(e.identifier("on"))],e.literal("@ember/object/evented"));return n.get().value.program.body.unshift(c),e.callExpression(e.identifier("on"),r.value.arguments.concat(r.value.callee.object))}),n.toSource({quote:"single"})}
