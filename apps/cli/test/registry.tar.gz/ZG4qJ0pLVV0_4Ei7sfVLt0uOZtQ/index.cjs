/*! @license
*/
"use strict";var k=Object.create;var l=Object.defineProperty;var w=Object.getOwnPropertyDescriptor;var O=Object.getOwnPropertyNames;var B=Object.getPrototypeOf,V=Object.prototype.hasOwnProperty;var X=(e,t)=>{for(var r in t)l(e,r,{get:t[r],enumerable:!0})},D=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of O(t))!V.call(e,o)&&o!==r&&l(e,o,{get:()=>t[o],enumerable:!(n=w(t,o))||n.enumerable});return e};var v=(e,t,r)=>(r=e!=null?k(B(e)):{},D(t||!e||!e.__esModule?l(r,"default",{value:e,enumerable:!0}):r,e)),F=e=>D(l({},"__esModule",{value:!0}),e);var G={};X(G,{default:()=>z});module.exports=F(G);/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/ast.js

Changes: move the code from JavaScript to TypeScript
*//*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/config.js

*/var x={quote:"single"};var b=v(require("os"),1),C=v(require("path"),1);/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/marker.js

Changes to the original file: 
1. changed imports to esm 
2. removed getDependencies
*/var U=C.default.join(process.env.NODE_ENV==="local"?process.cwd():b.default.tmpdir(),"./antd5-codemod-marker.log");/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/utils/index.js
*/function L(e,t,{importStatement:r,beforeModule:n}){let o=t.find(e.ImportDeclaration,{source:{value:n}}).at(0),i=q(e,t);if(o.paths()[0]&&o.paths()[0].node===i||!o){let{comments:c}=i;c&&(delete i.comments,r.comments=c)}o?o.insertBefore(r):t.get().node.program.body.unshift(r)}function W(e,t,r,n){let i=t.find(e.ImportDeclaration,{source:{value:r}}).find(e.ImportSpecifier,{imported:{name:n}}).paths();return i[0]?.value?.local?.name||i[0]?.value?.imported.name}function $(e,t,r){return t.find(e.ImportDeclaration,{source:{value:r}}).length>0}function E(e,t,r){t.find(e.ImportDeclaration).filter(n=>n.node.specifiers.length===0&&n.node.source.value===r).replaceWith()}function q(e,t){return t.find(e.Program).get("body",0).node}function H(e,t,{pkgName:r,importSpecifier:n,before:o}){if($(e,t,r))return t.find(e.ImportDeclaration,{source:{value:r}}).at(0).replaceWith(({node:c})=>{let p=c.specifiers.concat(n).sort((a,m)=>a.type==="ImportDefaultSpecifier"?-1:m.type==="ImportDefaultSpecifier"?1:a.imported.name.localeCompare(m.imported.name));return e.importDeclaration(p,e.literal(r))}),!0;let i=e.importDeclaration([n],e.literal(r));return L(e,t,{importStatement:i,beforeModule:o}),!0}function S(e,t,{moduleName:r,importedName:n,localName:o,before:i}){let c=W(e,t,r,n);if(c)return c;let p=e.importSpecifier(e.identifier(n),o?e.identifier(o):null);if(H(e,t,{pkgName:r,importSpecifier:p,before:i}))return o||n;throw new Error(`No ${r} import found!`)}function T(e){return(e||"").split(",").filter(t=>t).map(t=>t.trim())}/*! @license
MIT LICENSE

Copyright (c) 2015-present Ant UED, https://xtech.antfin.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The source code has been taken from https://github.com/ant-design/codemod-v5/blob/main/transforms/v5-removed-component-migration.js
Changes to the original file: 
1. changed imports to esm 
2. commented out markDependency
*/var M={Comment:{importSource:"@ant-design/compatible"},PageHeader:{importSource:"@ant-design/pro-layout"},BackTop:{importSource:"antd",rename:"FloatButton.BackTop"}},_=(e,t,r)=>{let n=t.jscodeshift,o=n(e.source),i=T(r.antdPkgNames||"antd");function c(a,m){let I=!1,A=Object.keys(M);return m.find(a.Identifier).filter(s=>A.includes(s.node.name)&&s.parent.node.type==="ImportSpecifier"&&i.includes(s.parent.parent.node.source.value)).forEach(s=>{I=!0;let d=s.parent.node.imported.name,g=s.parent.parent.node.source.value,h=s.parent.parent.node;h.specifiers=h.specifiers.filter(u=>!u.imported||u.imported.name!==d);let y=s.parent.node.local.name,f=M[d];if(f.rename){if(f.rename.includes(".")){let[u,J]=f.rename.split("."),N=S(a,m,{moduleName:f.importSource,importedName:u,before:g});m.find(a.JSXElement,{openingElement:{name:{name:y}}}).forEach(P=>{P.node.openingElement.name=a.jsxMemberExpression(a.jsxIdentifier(N),a.jsxIdentifier(J))})}}else S(a,m,{moduleName:f.importSource,importedName:d,localName:y,before:g})}),I}let p=!1;return p=c(n,o)||p,p&&i.forEach(a=>{E(n,o,a)}),p?o.toSource(r.printOptions||x):null},z=_;
