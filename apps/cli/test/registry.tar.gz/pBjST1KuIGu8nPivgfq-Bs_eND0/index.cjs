/*! @license
*/
"use strict";var l=Object.defineProperty;var c=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var u=Object.prototype.hasOwnProperty;var m=(a,t)=>{for(var o in t)l(a,o,{get:t[o],enumerable:!0})},d=(a,t,o,e)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of p(t))!u.call(a,r)&&r!==o&&l(a,r,{get:()=>t[r],enumerable:!(e=c(t,r))||e.enumerable});return a};var f=a=>d(l({},"__esModule",{value:!0}),a);var v={};m(v,{default:()=>s});module.exports=f(v);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added the options parameter
*/function s(a,t,o){let e=t.jscodeshift,r=e(a.source);if(!r.find(e.ImportDeclaration,{source:{value:"react-router-dom-v5-compat"}}).length){let i=e.importDeclaration([e.importSpecifier(e.identifier("useNavigate"))],e.literal("react-router-dom-v5-compat"));r.get().value.program.body.unshift(i)}return r.find(e.ImportDeclaration,{source:{value:"react-router-dom"}}).forEach(i=>{i.value.specifiers.filter(n=>n.imported.name==="useHistory").forEach(n=>{n.imported.name="useNavigate"})}),r.find(e.VariableDeclarator,{id:{name:"history"}}).replaceWith(()=>e.variableDeclarator(e.identifier("navigate"),e.callExpression(e.identifier("useNavigate"),[]))),r.find(e.CallExpression,{callee:{object:{name:"history"},property:{name:"push"}}}).replaceWith(i=>e.callExpression(e.identifier("navigate"),i.value.arguments)),r.find(e.CallExpression,{callee:{object:{name:"history"},property:{name:"replace"}}}).replaceWith(i=>e.callExpression(e.identifier("navigate"),[...i.value.arguments,e.objectExpression([e.objectProperty(e.identifier("replace"),e.booleanLiteral(!0),!1,!1)])])),r.find(e.CallExpression,{callee:{object:{name:"history"},property:{name:"go"}}}).replaceWith(i=>e.callExpression(e.identifier("navigate"),i.value.arguments)),r.toSource(o)}
