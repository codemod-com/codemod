/*! @license
*/
"use strict";var m=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var s=Object.getOwnPropertyNames;var f=Object.prototype.hasOwnProperty;var p=(n,e)=>{for(var r in e)m(n,r,{get:e[r],enumerable:!0})},c=(n,e,r,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let t of s(e))!f.call(n,t)&&t!==r&&m(n,t,{get:()=>e[t],enumerable:!(o=u(e,t))||o.enumerable});return n};var d=n=>c(m({},"__esModule",{value:!0}),n);var I={};p(I,{default:()=>g});module.exports=d(I);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function l(n,e,r){let o=e.jscodeshift,t=o(n.source),a=!1;if(!t.find(o.ImportDeclaration,{source:{value:"react-router-dom-v5-compat"}}).length){let i=o.importDeclaration([o.importSpecifier(o.identifier("CompatRoute"))],o.literal("react-router-dom-v5-compat"));t.get().value.program.body.unshift(i),a=!0}if(t.find(o.JSXElement,{openingElement:{name:{name:"Route"}}}).forEach(i=>{"name"in i.value.openingElement.name&&(i.value.openingElement.name.name="CompatRoute",a=!0)}),!!a)return t.toSource(r)}var g=l;
