# Remove Manual Memoization Hooks

## Description

This codemod will remove manual memoization hooks: `useCallback`, `useMemo` and `memo`. This codemod goes hand in hand with React Compiler.
