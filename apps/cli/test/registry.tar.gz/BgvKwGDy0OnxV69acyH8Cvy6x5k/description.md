# Generate Metadata Tests for Cal.com

## Description

This codemod generates metadata tests for all existing paths under the pages router.

It uses the `testPath` argument to place the test file in the proper place.