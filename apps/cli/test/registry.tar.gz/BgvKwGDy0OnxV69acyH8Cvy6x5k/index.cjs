/*! @license
*/
"use strict";var p=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var C=Object.getOwnPropertyNames;var h=Object.prototype.hasOwnProperty;var w=(t,e)=>{for(var n in e)p(t,n,{get:e[n],enumerable:!0})},x=(t,e,n,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let a of C(e))!h.call(t,a)&&a!==n&&p(t,a,{get:()=>e[a],enumerable:!(o=u(e,a))||o.enumerable});return t};var f=t=>x(p({},"__esModule",{value:!0}),t);var P={};w(P,{buildData:()=>c,repomod:()=>D});module.exports=f(P);var i=require("node:path"),c=t=>`
	import { expect } from "@playwright/test";

	import { test } from "../lib/fixtures";
	import { metadataCommons } from "../lib/metadata";
	
	test.describe("Metadata of ${t}", () => {
		test.afterEach(async ({ users }) => {
			await users.deleteAll();
		});
	
		test("emits proper metadata", async ({ page, users }) => {
			const user = await users.create();
			await user.apiLogin();
			await page.goto("${t}");
						
			expect(await metadataCommons.getTitle(page)).toMatch(/(TODO|Cal.com) | Cal.com/);
		
			expect(await metadataCommons.getCanonicalLinkHref(page)).toEqual("http://localhost:3000/${t}");
		
			expect(await metadataCommons.getAppleTouchIconHref(page)).toEqual("/api/logo?type=apple-touch-icon");
		
			expect(await metadataCommons.getManifestHref(page)).toEqual("/site.webmanifest");
		
			expect(await metadataCommons.getMaskIconHref(page)).toEqual("/safari-pinned-tab.svg");
			expect(await metadataCommons.getMaskIconColor(page)).toEqual("#000000");
		
			expect(await metadataCommons.getLink16Href(page)).toEqual("/api/logo?type=favicon-16");
		
			expect(await metadataCommons.getLink32Href(page)).toEqual("/api/logo?type=favicon-32");
		
			expect(await metadataCommons.getViewportContent(page)).toEqual(
			"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"
			);
		
			expect(await metadataCommons.getRobotsContent(page)).toEqual("index,follow");
		
			expect(await metadataCommons.getTileColorContent(page)).toEqual("#ff0000");
		
			expect(await metadataCommons.getLightSchemeName(page)).toEqual("theme-color");
		
			expect(await metadataCommons.getLightSchemeContent(page)).toEqual("#f9fafb");
		
			expect(await metadataCommons.getDarkSchemeName(page)).toEqual("theme-color");
		
			expect(await metadataCommons.getDarkSchemeContent(page)).toEqual("#1C1C1C");
		
			expect(await metadataCommons.getTwitterCardContent(page)).toEqual("summary_large_image");
		
			expect(await metadataCommons.getTwitterSiteContent(page)).toEqual("@calcom");
		
			expect(await metadataCommons.getTwitterAuthorContent(page)).toEqual("@calcom");
		
			expect(await metadataCommons.getOgDescriptionContent(page)).toEqual("TODO");
		
			expect(await metadataCommons.getOgUrlContent(page)).toEqual("http://localhost:3000/${t}");
		
			expect(await metadataCommons.getOgTypeContent(page)).toEqual("website");
		
			expect(await metadataCommons.getOgSiteNameContent(page)).toEqual("Cal.com");
		
			expect(await metadataCommons.getOgTitleContent(page)).toMatch(/(TODO|Cal.com) | Cal.com/);
		
			expect(
			(await metadataCommons.getOgImageContent(page))?.startsWith(
				"http://localhost:3000/_next/image?w=1200&q=100&url="
			)
			).toBeTruthy();
		});
	});
`,q=async t=>({testPath:typeof t.testPath=="string"?t.testPath:null}),E=async(t,e,n,o)=>{if(o===null||o.testPath===null)return[];let a=(0,i.parse)(e),s=a.dir.split(i.sep),g=s.length>0&&s.lastIndexOf("pages")===s.length-1,l=a.name==="index";if(g&&l)return[];let r=s.lastIndexOf("pages"),m=s.slice(r+1);l||m.push(a.name);let d=t.joinPaths(...m);return m[m.length-1]+=".e2e.ts",[{kind:"upsertFile",path:t.joinPaths(o.testPath,...m),options:{...n,appPath:d}}]},y=async(t,e,n,o)=>{let a=typeof o.appPath=="string"?o.appPath:null;return a===null?{kind:"noop"}:{kind:"upsertData",path:e,data:c(a)}},D={includePatterns:["**/pages/**/*.{js,jsx,ts,tsx}"],excludePatterns:["**/node_modules/**","**/pages/api/**"],initializeState:q,handleFile:E,handleData:y};0&&(module.exports={buildData,repomod});
