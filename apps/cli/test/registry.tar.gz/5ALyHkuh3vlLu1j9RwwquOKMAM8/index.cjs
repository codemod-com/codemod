/*! @license
*/
"use strict";var m=Object.defineProperty;var j=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var p=Object.prototype.hasOwnProperty;var v=(n,t)=>{for(var o in t)m(n,o,{get:t[o],enumerable:!0})},A=(n,t,o,e)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of h(t))!p.call(n,r)&&r!==o&&m(n,r,{get:()=>t[r],enumerable:!(e=j(t,r))||e.enumerable});return n};var S=n=>A(m({},"__esModule",{value:!0}),n);var b={};v(b,{default:()=>c});module.exports=S(b);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Changes to the original file: added the options parameter
*/function c(n,t,o){let e=t.jscodeshift,r=e(n.source),f=a=>function(i){return e.JSXElement.check(i.value)&&i.value.children.some(l=>e.JSXElement.check(l)&&l.openingElement.name.name===a)};return r.findJSXElements("Switch").filter(f("Redirect")).forEach(a=>{e(a).findJSXElements("Redirect").forEach(s=>{s.value.openingElement.name.name="Route";let i=s.value.openingElement.attributes,[l]=i.filter(u=>u.name.name==="from"),[E]=i.filter(u=>u.name.name==="to"),x=e.jsxElement(e.jsxOpeningElement(e.jsxIdentifier("Route"),[e.jsxAttribute(e.jsxIdentifier("to"),E.value)],!0),null,[],!1),d=[e.jsxAttribute(e.jsxIdentifier("path"),l.value),e.jsxAttribute(e.jsxIdentifier("render"),e.jsxExpressionContainer(e.arrowFunctionExpression([],x)))];s.value.openingElement.attributes=d})}),r.toSource(o)}
