# Remove Redirect Inside Switch

## Description

