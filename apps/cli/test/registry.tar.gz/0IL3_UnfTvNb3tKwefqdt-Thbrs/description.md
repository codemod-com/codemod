# Remove Active Classname

## Description

