/*! @license
*/
"use strict";var u=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var A=Object.prototype.hasOwnProperty;var E=(i,n)=>{for(var s in n)u(i,s,{get:n[s],enumerable:!0})},N=(i,n,s,e)=>{if(n&&typeof n=="object"||typeof n=="function")for(let t of x(n))!A.call(i,t)&&t!==s&&u(i,t,{get:()=>n[t],enumerable:!(e=p(n,t))||e.enumerable});return i};var y=i=>N(u({},"__esModule",{value:!0}),i);var I={};E(I,{default:()=>F});module.exports=y(I);/*! @license

The MIT License (MIT)

Copyright (c) 2023 Rajasegar Chandran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/function j(i,n,s){let e=n.jscodeshift,t=e(i.source),f=!1;if(t.findJSXElements("NavLink").forEach(c=>{let l=c.value.openingElement.attributes;if(!l)return;let[r]=l.filter(a=>"name"in a?a.name.name==="className":!1);if(!r||!("value"in r)||!r.value||!("value"in r.value)||!r.value.value)return;let[o]=l.filter(a=>"name"in a?a.name.name==="activeClassName":!1);if(!o||!("value"in o)||!o.value||!("value"in o.value))return;let v=l.findIndex(a=>"name"in a?a.name.name==="activeClassName":!1);l.splice(v,1);let m=e.property("init",e.literal("isActive"),e.identifier("isActive")),d=e.binaryExpression("+",e.literal(r.value.value),e.conditionalExpression(e.identifier("isActive"),e.literal(` ${o.value.value}`),e.literal("")));r.value=e.jsxExpressionContainer(e.arrowFunctionExpression([e.objectPattern([m])],d)),f=!0}),!!f)return t.toSource(s)}var F=j;
