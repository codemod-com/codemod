/*! @license
*/
"use strict";var l=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var k=Object.getOwnPropertyNames;var g=Object.prototype.hasOwnProperty;var b=(n,t)=>{for(var e in t)l(n,e,{get:t[e],enumerable:!0})},j=(n,t,e,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let i of k(t))!g.call(n,i)&&i!==e&&l(n,i,{get:()=>t[i],enumerable:!(a=h(t,i))||a.enumerable});return n};var v=n=>j(l({},"__esModule",{value:!0}),n);var x={};b(x,{default:()=>y});module.exports=v(x);/*! @license
The MIT License (MIT)

Copyright (c) 2023 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/function y(n,t){let e=t.jscodeshift,a=e(n.source),i=!1,c=a.find(e.ExportNamedDeclaration,{declaration:{type:"VariableDeclaration",declarations:[{id:{name:"metadata"}}]}});if(c.size()!==1)return;let m=c.find(e.ObjectExpression).get(0).node;if(!m){console.error("Could not find metadata object");return}let o=m.properties,s,p=o.find(r=>r.key.name==="viewport");p?(s=p.value.properties,o=o.filter(r=>r.key.name!=="viewport")):s=[];let d=o.find(r=>r.key.name==="colorScheme");d&&(s.push(d),o=o.filter(r=>r.key.name!=="colorScheme"));let f=o.find(r=>r.key.name==="themeColor");f&&(s.push(f),o=o.filter(r=>r.key.name!=="themeColor")),c.find(e.ObjectExpression).replaceWith(e.objectExpression(o));let u=e.exportNamedDeclaration(e.variableDeclaration("const",[e.variableDeclarator(e.identifier("viewport"),e.objectExpression(s))]));if(s.length&&(a.get().node.program.body.push(u),i=!0),!!i)return a.toSource()}
